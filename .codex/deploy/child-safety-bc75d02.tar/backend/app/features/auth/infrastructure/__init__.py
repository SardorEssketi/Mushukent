"""Auth infrastructure layer."""
