"""Auth domain layer."""
