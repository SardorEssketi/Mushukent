"""Cats presentation layer."""
