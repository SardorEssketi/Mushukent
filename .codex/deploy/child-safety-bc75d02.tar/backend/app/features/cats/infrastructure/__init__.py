"""Cats infrastructure layer."""
