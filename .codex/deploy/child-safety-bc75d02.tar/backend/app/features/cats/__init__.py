"""Cats feature module skeleton."""
