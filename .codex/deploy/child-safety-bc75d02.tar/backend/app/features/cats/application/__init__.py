"""Cats application layer."""
