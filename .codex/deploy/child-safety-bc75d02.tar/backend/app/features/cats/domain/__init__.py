"""Cats domain layer."""
