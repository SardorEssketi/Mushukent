"""Leaderboard application layer."""
