"""Leaderboard presentation layer."""
