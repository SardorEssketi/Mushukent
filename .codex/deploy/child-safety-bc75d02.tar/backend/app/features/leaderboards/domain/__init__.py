"""Leaderboard domain layer."""
