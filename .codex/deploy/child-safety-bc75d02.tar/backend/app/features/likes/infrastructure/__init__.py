"""Likes infrastructure layer."""
