"""Likes domain layer."""
