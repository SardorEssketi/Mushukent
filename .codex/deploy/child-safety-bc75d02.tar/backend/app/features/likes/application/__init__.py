"""Likes application layer."""
