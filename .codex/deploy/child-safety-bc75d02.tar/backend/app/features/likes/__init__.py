"""Likes feature module skeleton."""
