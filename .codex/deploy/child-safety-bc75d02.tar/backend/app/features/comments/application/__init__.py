"""Comments application layer."""
