"""Posts domain layer."""
