"""Core cross-cutting modules."""
