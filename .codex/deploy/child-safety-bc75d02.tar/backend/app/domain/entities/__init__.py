"""Domain entities live here."""
