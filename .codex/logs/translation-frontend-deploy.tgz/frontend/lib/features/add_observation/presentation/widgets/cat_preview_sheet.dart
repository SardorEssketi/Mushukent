import 'package:flutter/material.dart';

import '../../../../core/localization/app_strings.dart';
import '../../../../core/localization/language_controller.dart';
import '../../../../core/network/mushukistan_api.dart';

class CatPreviewSheet extends StatelessWidget {
  const CatPreviewSheet({
    super.key,
    required this.cats,
    required this.selectedCatId,
    required this.useNewCat,
    required this.onSelectCat,
    required this.onUseNewCat,
  });

  final List<CatSummary> cats;
  final String? selectedCatId;
  final bool useNewCat;
  final ValueChanged<String?> onSelectCat;
  final VoidCallback onUseNewCat;

  @override
  Widget build(BuildContext context) {
    final strings = AppStrings.forLanguage(AppLanguage.fromCode(
      Localizations.localeOf(context).languageCode,
    ));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(strings.nearbyCats,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            if (cats.isEmpty)
              Text(strings.noNearbyCatsFound)
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final cat in cats)
                    ChoiceChip(
                      label: Text(cat.name ?? strings.unnamedCat),
                      selected: selectedCatId == cat.id,
                      onSelected: (selected) {
                        if (selected) {
                          onSelectCat(cat.id);
                        } else {
                          onSelectCat(null);
                        }
                      },
                    ),
                ],
              ),
            const Divider(height: 24),
            Align(
              alignment: Alignment.centerLeft,
              child: ChoiceChip(
                selected: useNewCat,
                onSelected: (_) => onUseNewCat(),
                avatar: const Icon(Icons.add_circle_outline, size: 18),
                label: Text(strings.thisIsNewCat),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
