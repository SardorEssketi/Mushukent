﻿import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'language_controller.dart';

final appStringsProvider = Provider<AppStrings>((ref) {
  return AppStrings.forLanguage(ref.watch(appLanguageProvider));
});

class AppStrings {
  const AppStrings({
    required this.welcomeBack,
    required this.signInToMushukistan,
    required this.email,
    required this.emailHint,
    required this.password,
    required this.login,
    required this.continueWithGoogle,
    required this.createAnAccount,
    required this.createAccount,
    required this.joinMushukistan,
    required this.nameOptional,
    required this.register,
    required this.alreadyHaveAccount,
    required this.language,
    required this.emailRequired,
    required this.invalidEmail,
    required this.passwordRequired,
    required this.passwordMin8,
    required this.nameTooLong,
    required this.verifyEmail,
    required this.confirmYourEmail,
    required this.verifyEmailWithoutAddress,
    required this.verifyEmailWithAddress,
    required this.devVerificationHelp,
    required this.verifyNow,
    required this.resendVerification,
    required this.backToLogin,
    required this.sessionCheckFailed,
    required this.retry,
    required this.continueToLogin,
    required this.restoringSession,
    required this.feed,
    required this.map,
    required this.add,
    required this.leaders,
    required this.profile,
    required this.addObservation,
    required this.chooseFromGallery,
    required this.gallerySubtitle,
    required this.takePhoto,
    required this.cameraSubtitle,
    required this.refresh,
    required this.centerOnUser,
    required this.cats,
    required this.vets,
    required this.shops,
    required this.shelters,
    required this.couldNotLoadPlaceMarkers,
    required this.couldNotLoadCatMarkers,
    required this.couldNotResolveLocation,
    required this.sourceOpenStreetMap,
    required this.sourceMushukistan,
    required this.recent,
    required this.popular,
    required this.nearby,
    required this.needsHelp,
    required this.injured,
    required this.lostPets,
    required this.today,
    required this.month,
    required this.allTime,
    required this.noObservationsYet,
    required this.anonymous,
    required this.unnamedCat,
    required this.openPost,
    required this.like,
    required this.unlike,
    required this.comments,
    required this.myObservations,
    required this.myComments,
    required this.userObservations,
    required this.userComments,
    required this.noCommentsYet,
    required this.noActivityVisible,
    required this.noDescription,
    required this.privacy,
    required this.allowPublicActivityView,
    required this.allowPublicActivityViewSubtitle,
    required this.viewCommentsPrefix,
    required this.viewCommentsSuffix,
    required this.likes,
    required this.leaderboard,
    required this.mostActive,
    required this.mostPopular,
    required this.topHelpers,
    required this.day,
    required this.week,
    required this.noLeaderboardData,
    required this.unnamedUser,
    required this.observations,
    required this.score,
    required this.settings,
    required this.editProfile,
    required this.logout,
    required this.confirmLogoutTitle,
    required this.confirmLogoutMessage,
    required this.cancel,
    required this.registered,
    required this.likesReceived,
    required this.theme,
    required this.themeAuto,
    required this.themeDark,
    required this.themeLight,
    required this.saveChanges,
    required this.changesSaved,
    required this.couldNotSaveChanges,
  });

  final String welcomeBack;
  final String signInToMushukistan;
  final String email;
  final String emailHint;
  final String password;
  final String login;
  final String continueWithGoogle;
  final String createAnAccount;
  final String createAccount;
  final String joinMushukistan;
  final String nameOptional;
  final String register;
  final String alreadyHaveAccount;
  final String language;
  final String emailRequired;
  final String invalidEmail;
  final String passwordRequired;
  final String passwordMin8;
  final String nameTooLong;
  final String verifyEmail;
  final String confirmYourEmail;
  final String verifyEmailWithoutAddress;
  final String verifyEmailWithAddress;
  final String devVerificationHelp;
  final String verifyNow;
  final String resendVerification;
  final String backToLogin;
  final String sessionCheckFailed;
  final String retry;
  final String continueToLogin;
  final String restoringSession;
  final String feed;
  final String map;
  final String add;
  final String leaders;
  final String profile;
  final String addObservation;
  final String chooseFromGallery;
  final String gallerySubtitle;
  final String takePhoto;
  final String cameraSubtitle;
  final String refresh;
  final String centerOnUser;
  final String cats;
  final String vets;
  final String shops;
  final String shelters;
  final String couldNotLoadPlaceMarkers;
  final String couldNotLoadCatMarkers;
  final String couldNotResolveLocation;
  final String sourceOpenStreetMap;
  final String sourceMushukistan;
  final String recent;
  final String popular;
  final String nearby;
  final String needsHelp;
  final String injured;
  final String lostPets;
  final String today;
  final String month;
  final String allTime;
  final String noObservationsYet;
  final String anonymous;
  final String unnamedCat;
  final String openPost;
  final String like;
  final String unlike;
  final String comments;
  final String myObservations;
  final String myComments;
  final String userObservations;
  final String userComments;
  final String noCommentsYet;
  final String noActivityVisible;
  final String noDescription;
  final String privacy;
  final String allowPublicActivityView;
  final String allowPublicActivityViewSubtitle;
  final String viewCommentsPrefix;
  final String viewCommentsSuffix;
  final String likes;
  final String leaderboard;
  final String mostActive;
  final String mostPopular;
  final String topHelpers;
  final String day;
  final String week;
  final String noLeaderboardData;
  final String unnamedUser;
  final String observations;
  final String score;
  final String settings;
  final String editProfile;
  final String logout;
  final String confirmLogoutTitle;
  final String confirmLogoutMessage;
  final String cancel;
  final String registered;
  final String likesReceived;
  final String theme;
  final String themeAuto;
  final String themeDark;
  final String themeLight;
  final String saveChanges;
  final String changesSaved;
  final String couldNotSaveChanges;

  String get acceptTermsAndPrivacy {
    return switch (this) {
      _UzbekStrings() =>
        'Foydalanish shartlari va Maxfiylik siyosatini qabul qiling.',
      _RussianStrings() =>
        'РџСЂРёРјРёС‚Рµ РЈСЃР»РѕРІРёСЏ РёСЃРїРѕР»СЊР·РѕРІР°РЅРёСЏ Рё РџРѕР»РёС‚РёРєСѓ РєРѕРЅС„РёРґРµРЅС†РёР°Р»СЊРЅРѕСЃС‚Рё.',
      _ => 'Accept the Terms of Service and Privacy Policy.',
    };
  }

  String get nameRequired {
    return switch (this) {
      _UzbekStrings() => 'Ism kiritilishi kerak.',
      _RussianStrings() => 'РЈРєР°Р¶РёС‚Рµ РёРјСЏ.',
      _ => 'Name is required.',
    };
  }

  String get googleLegalConsentTitle {
    return switch (this) {
      _UzbekStrings() => 'Davom etishdan oldin',
      _RussianStrings() => 'РџРµСЂРµРґ РїСЂРѕРґРѕР»Р¶РµРЅРёРµРј',
      _ => 'Before you continue',
    };
  }

  String get googleLegalConsentMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Google hisobingiz bilan Mushukistan hisobini yaratish uchun huquqiy hujjatlarni qabul qiling.',
      _RussianStrings() =>
        'РџСЂРёРјРёС‚Рµ СЋСЂРёРґРёС‡РµСЃРєРёРµ РґРѕРєСѓРјРµРЅС‚С‹, С‡С‚РѕР±С‹ СЃРѕР·РґР°С‚СЊ Р°РєРєР°СѓРЅС‚ Mushukistan С‡РµСЂРµР· Google.',
      _ =>
        'Accept the legal documents to create your Mushukistan account with Google.',
    };
  }

  String get acceptLegalLeading {
    return switch (this) {
      _UzbekStrings() => 'Men ',
      _RussianStrings() => 'РЇ РїСЂРёРЅРёРјР°СЋ ',
      _ => 'I accept the ',
    };
  }

  String get acceptLegalTrailing {
    return switch (this) {
      _UzbekStrings() => 'ni qabul qilaman.',
      _ => '.',
    };
  }

  String get termsOfService {
    return switch (this) {
      _UzbekStrings() => 'Foydalanish shartlari',
      _RussianStrings() => 'РЈСЃР»РѕРІРёСЏ РёСЃРїРѕР»СЊР·РѕРІР°РЅРёСЏ',
      _ => 'Terms of Service',
    };
  }

  String get privacyPolicy {
    return switch (this) {
      _UzbekStrings() => 'Maxfiylik siyosati',
      _RussianStrings() => 'РџРѕР»РёС‚РёРєР° РєРѕРЅС„РёРґРµРЅС†РёР°Р»СЊРЅРѕСЃС‚Рё',
      _ => 'Privacy Policy',
    };
  }

  String get aboutAccount {
    return switch (this) {
      _UzbekStrings() => 'Hisob haqida',
      _RussianStrings() => 'РћР± Р°РєРєР°СѓРЅС‚Рµ',
      _ => 'About account',
    };
  }

  String get phoneNumber {
    return switch (this) {
      _UzbekStrings() => 'Telefon raqami',
      _RussianStrings() => 'РќРѕРјРµСЂ С‚РµР»РµС„РѕРЅР°',
      _ => 'Phone number',
    };
  }

  String get notAdded {
    return switch (this) {
      _UzbekStrings() => 'QoвЂshilmagan',
      _RussianStrings() => 'РќРµ РґРѕР±Р°РІР»РµРЅ',
      _ => 'Not added',
    };
  }

  String get privacyPolicySummary {
    return switch (this) {
      _UzbekStrings() =>
        'Mushukistan xarita va lenta uchun hisob, profil, ochiq postlar, rasmlar, izohlar, shikoyatlar va joylashuv maвЂ™lumotlarini saqlaydi. Tekshirilgan MVPвЂ™da analitika, reklama, push, crash SDK yoki AI funksiyasi yoвЂq.',
      _RussianStrings() =>
        'Mushukistan С…СЂР°РЅРёС‚ РґР°РЅРЅС‹Рµ Р°РєРєР°СѓРЅС‚Р°, РїСЂРѕС„РёР»СЏ, РїСѓР±Р»РёС‡РЅС‹Рµ РїРѕСЃС‚С‹, С„РѕС‚Рѕ, РєРѕРјРјРµРЅС‚Р°СЂРёРё, Р¶Р°Р»РѕР±С‹ Рё РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёСЏ РґР»СЏ РєР°СЂС‚С‹ Рё Р»РµРЅС‚С‹. Р’ РїСЂРѕРІРµСЂРµРЅРЅРѕРј MVP РЅРµС‚ Р°РЅР°Р»РёС‚РёРєРё, СЂРµРєР»Р°РјС‹, push-СѓРІРµРґРѕРјР»РµРЅРёР№, crash SDK РёР»Рё AI-С„СѓРЅРєС†РёР№.',
      _ =>
        'Mushukistan stores account data, profile data, public posts, photos, comments, reports, and locations needed for map and feed features. No analytics, ads, push, crash SDK, or AI feature is included in the verified MVP.',
    };
  }

  String get termsOfServiceSummary {
    return switch (this) {
      _UzbekStrings() =>
        'MushukistanвЂ™dan faqat qonuniy mushuk va yoвЂqolgan jonivor kontenti uchun foydalaning. Shaxsiy maвЂ™lumotlar, haqorat, spam, noqonuniy kontent yoki ruxsatsiz mualliflik materiallarini joylamang.',
      _RussianStrings() =>
        'РСЃРїРѕР»СЊР·СѓР№С‚Рµ Mushukistan С‚РѕР»СЊРєРѕ РґР»СЏ Р·Р°РєРѕРЅРЅРѕРіРѕ РєРѕРЅС‚РµРЅС‚Р° Рѕ РєРѕС€РєР°С… Рё РїРѕС‚РµСЂСЏРЅРЅС‹С… РїРёС‚РѕРјС†Р°С…, РєРѕС‚РѕСЂС‹Рј РІС‹ РІРїСЂР°РІРµ РґРµР»РёС‚СЊСЃСЏ. РќРµ РїСѓР±Р»РёРєСѓР№С‚Рµ Р»РёС‡РЅС‹Рµ РґР°РЅРЅС‹Рµ, РѕСЃРєРѕСЂР±Р»РµРЅРёСЏ, СЃРїР°Рј, РЅРµР·Р°РєРѕРЅРЅС‹Р№ РєРѕРЅС‚РµРЅС‚ РёР»Рё РјР°С‚РµСЂРёР°Р»С‹ Р±РµР· СЂР°Р·СЂРµС€РµРЅРёСЏ РїСЂР°РІРѕРѕР±Р»Р°РґР°С‚РµР»СЏ.',
      _ =>
        'Use Mushukistan only for lawful cat and lost-pet content you have permission to share. Do not post private personal data, harassment, spam, illegal content, or copyrighted material without permission.',
    };
  }

  String get accountDeletion {
    return switch (this) {
      _UzbekStrings() => 'Hisobni oвЂchirish',
      _RussianStrings() => 'РЈРґР°Р»РµРЅРёРµ Р°РєРєР°СѓРЅС‚Р°',
      _ => 'Account deletion',
    };
  }

  String get accountDeletionSummary {
    return switch (this) {
      _UzbekStrings() =>
        'Hisob oвЂchirilsa, kirish oвЂchadi, profil shaxsiy maвЂ™lumotlari olib tashlanadi, postlar, izohlar va yoвЂqolgan jonivor postlari yashiriladi va anonimlashtiriladi, telefon nusxalari hamda layklar oвЂchiriladi, media fayllarni tozalashga urinish qilinadi.',
      _RussianStrings() =>
        'РЈРґР°Р»РµРЅРёРµ Р°РєРєР°СѓРЅС‚Р° РѕС‚РєР»СЋС‡Р°РµС‚ РІС…РѕРґ, СѓРґР°Р»СЏРµС‚ РїРµСЂСЃРѕРЅР°Р»СЊРЅС‹Рµ РґР°РЅРЅС‹Рµ РїСЂРѕС„РёР»СЏ, СЃРєСЂС‹РІР°РµС‚ Рё Р°РЅРѕРЅРёРјРёР·РёСЂСѓРµС‚ РІР°С€Рё РїРѕСЃС‚С‹, РєРѕРјРјРµРЅС‚Р°СЂРёРё Рё РїРѕСЃС‚С‹ Рѕ РїРѕС‚РµСЂСЏРЅРЅС‹С… РїРёС‚РѕРјС†Р°С…, СѓРґР°Р»СЏРµС‚ СЃРѕС…СЂР°РЅРµРЅРЅС‹Рµ РєРѕРїРёРё С‚РµР»РµС„РѕРЅР° Рё Р»Р°Р№РєРё, Р° С‚Р°РєР¶Рµ РїС‹С‚Р°РµС‚СЃСЏ РѕС‡РёСЃС‚РёС‚СЊ РјРµРґРёР°С„Р°Р№Р»С‹.',
      _ =>
        'Deleting your account disables login, removes profile personal data, hides and anonymizes your posts, comments, and lost-pet posts, removes copied phone numbers, deletes likes, and attempts media cleanup.',
    };
  }

  String get chooseYourLanguage {
    return switch (this) {
      _UzbekStrings() => 'Tilni tanlang',
      _RussianStrings() => 'Р’С‹Р±РµСЂРёС‚Рµ СЏР·С‹Рє',
      _ => 'Choose your language',
    };
  }

  String get chooseLanguageSubtitle {
    return switch (this) {
      _UzbekStrings() =>
        'Mushukistan ichida ishlatmoqchi boвЂlgan tilni tanlang.',
      _RussianStrings() =>
        'Р’С‹Р±РµСЂРёС‚Рµ СЏР·С‹Рє, РєРѕС‚РѕСЂС‹Р№ С…РѕС‚РёС‚Рµ РёСЃРїРѕР»СЊР·РѕРІР°С‚СЊ РІ Mushukistan.',
      _ => 'Set the language you want to use inside Mushukistan.',
    };
  }

  String get continueAction {
    return switch (this) {
      _UzbekStrings() => 'Davom etish',
      _RussianStrings() => 'РџСЂРѕРґРѕР»Р¶РёС‚СЊ',
      _ => 'Continue',
    };
  }

  String get welcomeToMushukistan {
    return switch (this) {
      _UzbekStrings() => 'Mushukistanga xush kelibsiz',
      _RussianStrings() => 'Р”РѕР±СЂРѕ РїРѕР¶Р°Р»РѕРІР°С‚СЊ РІ Mushukistan',
      _ => 'Welcome to Mushukistan',
    };
  }

  String get welcomeSupportMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Salom! Men Sardorman, Data Science yoвЂnalishida oвЂqiyman. Bu ilovani yon loyiha sifatida oвЂzim yaratdim va xarajatlarini oвЂzim qopladim. Ilova butunlay bepul va reklamasiz.',
      _RussianStrings() =>
        'РџСЂРёРІРµС‚! РЇ РЎР°СЂРґРѕСЂ, СЃС‚СѓРґРµРЅС‚ Data Science. РЇ СЃРѕР·РґР°Р» СЌС‚Рѕ РїСЂРёР»РѕР¶РµРЅРёРµ РєР°Рє Р»РёС‡РЅС‹Р№ РїСЂРѕРµРєС‚ Рё С„РёРЅР°РЅСЃРёСЂСѓСЋ РµРіРѕ СЃР°Рј. РћРЅРѕ РїРѕР»РЅРѕСЃС‚СЊСЋ Р±РµСЃРїР»Р°С‚РЅРѕРµ Рё Р±РµР· СЂРµРєР»Р°РјС‹.',
      _ =>
        'Hi there! IвЂ™m Sardor, a Data Science student. I built this app as a side project and funded it myself, and itвЂ™s completely free and ad-free.',
    };
  }

  String get supportMyWork {
    return switch (this) {
      _UzbekStrings() => 'Ishimni qoвЂllab-quvvatlash',
      _RussianStrings() => 'РџРѕРґРґРµСЂР¶Р°С‚СЊ РјРѕСЋ СЂР°Р±РѕС‚Сѓ',
      _ => 'Support my work',
    };
  }

  String get supportCardIntro {
    return switch (this) {
      _UzbekStrings() =>
        'Agar ishimni qoвЂllab-quvvatlamoqchi boвЂlsangiz, kartam:',
      _RussianStrings() => 'Р•СЃР»Рё С…РѕС‚РёС‚Рµ РїРѕРґРґРµСЂР¶Р°С‚СЊ РјРѕСЋ СЂР°Р±РѕС‚Сѓ, РІРѕС‚ РјРѕСЏ РєР°СЂС‚Р°:',
      _ => 'If youвЂ™d like to support my work, hereвЂ™s my card:',
    };
  }

  String get startExploring {
    return switch (this) {
      _UzbekStrings() => 'Boshlash',
      _RussianStrings() => 'РќР°С‡Р°С‚СЊ',
      _ => 'Start exploring',
    };
  }

  String get lostPet {
    return switch (this) {
      _UzbekStrings() => 'YoвЂqolgan jonivor',
      _RussianStrings() => 'РџРѕС‚РµСЂСЏРЅРЅС‹Р№ РїРёС‚РѕРјРµС†',
      _ => 'Lost Pet',
    };
  }

  String get create {
    return switch (this) {
      _UzbekStrings() => 'Yaratish',
      _RussianStrings() => 'РЎРѕР·РґР°С‚СЊ',
      _ => 'Create',
    };
  }

  String get whatAreYouCreating {
    return switch (this) {
      _UzbekStrings() => 'Nima yaratmoqchisiz?',
      _RussianStrings() => 'Р§С‚Рѕ РІС‹ СЃРѕР·РґР°РµС‚Рµ?',
      _ => 'What are you creating?',
    };
  }

  String get chooseTypeFirst {
    return switch (this) {
      _UzbekStrings() =>
        'Avval turini tanlang, shunda Mushukistan faqat kerakli maКјlumotlarni soК»raydi.',
      _RussianStrings() =>
        'РЎРЅР°С‡Р°Р»Р° РІС‹Р±РµСЂРёС‚Рµ С‚РёРї, С‡С‚РѕР±С‹ Mushukistan Р·Р°РїСЂРѕСЃРёР» С‚РѕР»СЊРєРѕ РЅСѓР¶РЅС‹Рµ РґР°РЅРЅС‹Рµ.',
      _ =>
        'Choose the right type first so Mushukistan can ask only for the details that matter.',
    };
  }

  String get catObservation {
    return switch (this) {
      _UzbekStrings() => 'Mushuk kuzatuvi',
      _RussianStrings() => 'РќР°Р±Р»СЋРґРµРЅРёРµ Р·Р° РєРѕС€РєРѕР№',
      _ => 'Cat observation',
    };
  }

  String get catObservationSubtitle {
    return switch (this) {
      _UzbekStrings() =>
        'Mushuk rasmlarini qoК»shing, kerak boК»lsa joylashuvni belgilang va yordam kerak mushuklarni koвЂrsating.',
      _RussianStrings() =>
        'Р”РѕР±Р°РІСЊС‚Рµ С„РѕС‚Рѕ РєРѕС€РєРё, РїСЂРё РЅРµРѕР±С…РѕРґРёРјРѕСЃС‚Рё СѓРєР°Р¶РёС‚Рµ РјРµСЃС‚Рѕ Рё РѕС‚РјРµС‚СЊС‚Рµ РєРѕС€РµРє, РєРѕС‚РѕСЂС‹Рј РЅСѓР¶РЅР° РїРѕРјРѕС‰СЊ.',
      _ =>
        'Add cat photos, attach a location if useful, and tag cats that need help.',
    };
  }

  String get lostPetAlert {
    return switch (this) {
      _UzbekStrings() => 'YoК»qolgan jonivor eКјloni',
      _RussianStrings() => 'РћР±СЉСЏРІР»РµРЅРёРµ Рѕ РїРѕС‚РµСЂСЏРЅРЅРѕРј РїРёС‚РѕРјС†Рµ',
      _ => 'Lost pet alert',
    };
  }

  String get lostPetAlertSubtitle {
    return switch (this) {
      _UzbekStrings() =>
        'Jonivor rasmlari, oxirgi koК»rilgan joy, holat va egasining aloqasi.',
      _RussianStrings() =>
        'Р¤РѕС‚Рѕ РїРёС‚РѕРјС†Р°, РїРѕСЃР»РµРґРЅРµРµ РјРµСЃС‚Рѕ, СЃС‚Р°С‚СѓСЃ Рё РєРѕРЅС‚Р°РєС‚ РІР»Р°РґРµР»СЊС†Р°.',
      _ => 'Pet photos, last-seen map point, status, and owner contact.',
    };
  }

  String get findANewHome {
    return switch (this) {
      _UzbekStrings() => 'Yangi uy topish',
      _RussianStrings() => 'РќР°Р№С‚Рё РЅРѕРІС‹Р№ РґРѕРј',
      _ => 'Find a new home',
    };
  }

  String get findANewHomeSubtitle {
    return switch (this) {
      _UzbekStrings() =>
        'Rasmlar, tavsif va egasining aloqasi bilan alohida uy topish posti. Xarita kerak emas.',
      _RussianStrings() =>
        'РћС‚РґРµР»СЊРЅС‹Р№ РїРѕСЃС‚ Рѕ РїСЂРёСЃС‚СЂРѕР№СЃС‚РІРµ СЃ С„РѕС‚Рѕ, РѕРїРёСЃР°РЅРёРµРј Рё РєРѕРЅС‚Р°РєС‚РѕРј РІР»Р°РґРµР»СЊС†Р°. РљР°СЂС‚Р° РЅРµ РЅСѓР¶РЅР°.',
      _ =>
        'A separate rehoming post with photos, description, and owner contact. No map required.',
    };
  }

  String get preparingPhotoForUpload {
    return switch (this) {
      _UzbekStrings() => 'Rasm yuklashga tayyorlanmoqda...',
      _RussianStrings() => 'Р¤РѕС‚Рѕ РіРѕС‚РѕРІРёС‚СЃСЏ Рє Р·Р°РіСЂСѓР·РєРµ...',
      _ => 'Preparing photo for upload...',
    };
  }

  String couldNotPreparePhoto(Object error) {
    return switch (this) {
      _UzbekStrings() => 'Rasmni tayyorlab boК»lmadi: $error',
      _RussianStrings() => 'РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕРґРіРѕС‚РѕРІРёС‚СЊ С„РѕС‚Рѕ: $error',
      _ => 'Could not prepare photo: $error',
    };
  }

  String get continueDraft {
    return switch (this) {
      _UzbekStrings() => 'Qoralamani davom ettirish',
      _RussianStrings() => 'РџСЂРѕРґРѕР»Р¶РёС‚СЊ С‡РµСЂРЅРѕРІРёРє',
      _ => 'Continue draft',
    };
  }

  String get deleteDraft {
    return switch (this) {
      _UzbekStrings() => 'Qoralamani oК»chirish',
      _RussianStrings() => 'РЈРґР°Р»РёС‚СЊ С‡РµСЂРЅРѕРІРёРє',
      _ => 'Delete draft',
    };
  }

  String get draftDeleted {
    return switch (this) {
      _UzbekStrings() => 'Qoralama oК»chirildi.',
      _RussianStrings() => 'Р§РµСЂРЅРѕРІРёРє СѓРґР°Р»РµРЅ.',
      _ => 'Draft deleted.',
    };
  }

  String get addCatPhotos {
    return switch (this) {
      _UzbekStrings() => 'Mushuk rasmlarini qoК»shish',
      _RussianStrings() => 'Р”РѕР±Р°РІРёС‚СЊ С„РѕС‚Рѕ РєРѕС€РєРё',
      _ => 'Add cat photos',
    };
  }

  String get selectUpToFivePhotos {
    return switch (this) {
      _UzbekStrings() => 'Besh tagacha rasm tanlang.',
      _RussianStrings() => 'Р’С‹Р±РµСЂРёС‚Рµ РґРѕ РїСЏС‚Рё С„РѕС‚Рѕ.',
      _ => 'Select up to five photos.',
    };
  }

  String get takeAPhoto {
    return switch (this) {
      _UzbekStrings() => 'Rasmga olish',
      _RussianStrings() => 'РЎРґРµР»Р°С‚СЊ С„РѕС‚Рѕ',
      _ => 'Take a photo',
    };
  }

  String get useCameraThenChooseLocation {
    return switch (this) {
      _UzbekStrings() => 'Kameradan foydalaning, keyin joylashuvni tanlang.',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·СѓР№С‚Рµ РєР°РјРµСЂСѓ, Р·Р°С‚РµРј РІС‹Р±РµСЂРёС‚Рµ РјРµСЃС‚Рѕ.',
      _ => 'Use the camera, then choose location.',
    };
  }

  String get deleteDraftTitle {
    return switch (this) {
      _UzbekStrings() => 'Qoralama oК»chirilsinmi?',
      _RussianStrings() => 'РЈРґР°Р»РёС‚СЊ С‡РµСЂРЅРѕРІРёРє?',
      _ => 'Delete draft?',
    };
  }

  String get deleteDraftMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Bu qoralamadagi tanlangan rasmlar, joylashuv, tavsif va mushuk tanlovini olib tashlaydi.',
      _RussianStrings() =>
        'Р­С‚Рѕ СѓРґР°Р»РёС‚ РёР· С‡РµСЂРЅРѕРІРёРєР° РІС‹Р±СЂР°РЅРЅС‹Рµ С„РѕС‚Рѕ, РјРµСЃС‚Рѕ, РѕРїРёСЃР°РЅРёРµ Рё РІС‹Р±РѕСЂ РєРѕС€РєРё.',
      _ =>
        'This removes the selected photos, location, description, and cat choice from this draft.',
    };
  }

  String get delete {
    return switch (this) {
      _UzbekStrings() => 'OК»chirish',
      _RussianStrings() => 'РЈРґР°Р»РёС‚СЊ',
      _ => 'Delete',
    };
  }

  String get useCurrentLocationTitle {
    return switch (this) {
      _UzbekStrings() => 'Joriy joylashuv ishlatilsinmi?',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ С‚РµРєСѓС‰РµРµ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ?',
      _ => 'Use current location?',
    };
  }

  String get useCurrentLocationMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Mushukistan joriy joylashuvingizni oК»qib, uni ushbu kuzatuvga biriktiradi. Postni joylasangiz, mushuk joylashuvi boshqa foydalanuvchilarga koК»rinishi mumkin.',
      _RussianStrings() =>
        'Mushukistan РїРѕР»СѓС‡РёС‚ РІР°С€Рµ С‚РµРєСѓС‰РµРµ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ Рё РїСЂРёРєСЂРµРїРёС‚ РµРіРѕ Рє СЌС‚РѕРјСѓ РЅР°Р±Р»СЋРґРµРЅРёСЋ. РџРѕСЃР»Рµ РїСѓР±Р»РёРєР°С†РёРё РјРµСЃС‚Рѕ РєРѕС€РєРё РјРѕР¶РµС‚ Р±С‹С‚СЊ РІРёРґРЅРѕ РґСЂСѓРіРёРј РїРѕР»СЊР·РѕРІР°С‚РµР»СЏРј.',
      _ =>
        'Mushukistan will read your current location and attach it to this observation. If you publish the post, that cat location can be visible to other users.',
    };
  }

  String get draftStatus {
    return switch (this) {
      _UzbekStrings() => 'Qoralama holati',
      _RussianStrings() => 'РЎС‚Р°С‚СѓСЃ С‡РµСЂРЅРѕРІРёРєР°',
      _ => 'Draft status',
    };
  }

  String get photo {
    return switch (this) {
      _UzbekStrings() => 'Rasm',
      _RussianStrings() => 'Р¤РѕС‚Рѕ',
      _ => 'Photo',
    };
  }

  String get selected {
    return switch (this) {
      _UzbekStrings() => 'Tanlangan',
      _RussianStrings() => 'Р’С‹Р±СЂР°РЅРѕ',
      _ => 'Selected',
    };
  }

  String get missing {
    return switch (this) {
      _UzbekStrings() => 'Yetishmayapti',
      _RussianStrings() => 'РќРµ СѓРєР°Р·Р°РЅРѕ',
      _ => 'Missing',
    };
  }

  String get location {
    return switch (this) {
      _UzbekStrings() => 'Joylashuv',
      _RussianStrings() => 'РњРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ',
      _ => 'Location',
    };
  }

  String get set {
    return switch (this) {
      _UzbekStrings() => 'Belgilangan',
      _RussianStrings() => 'РЈРєР°Р·Р°РЅРѕ',
      _ => 'Set',
    };
  }

  String get catChoice {
    return switch (this) {
      _UzbekStrings() => 'Mushuk tanlovi',
      _RussianStrings() => 'Р’С‹Р±РѕСЂ РєРѕС€РєРё',
      _ => 'Cat choice',
    };
  }

  String get newCat {
    return switch (this) {
      _UzbekStrings() => 'Yangi mushuk',
      _RussianStrings() => 'РќРѕРІР°СЏ РєРѕС€РєР°',
      _ => 'New cat',
    };
  }

  String get existingCat {
    return switch (this) {
      _UzbekStrings() => 'Mavjud mushuk',
      _RussianStrings() => 'РЎСѓС‰РµСЃС‚РІСѓСЋС‰Р°СЏ РєРѕС€РєР°',
      _ => 'Existing cat',
    };
  }

  String get visibility {
    return switch (this) {
      _UzbekStrings() => 'KoК»rinish',
      _RussianStrings() => 'Р’РёРґРёРјРѕСЃС‚СЊ',
      _ => 'Visibility',
    };
  }

  String get public {
    return switch (this) {
      _UzbekStrings() => 'Ochiq',
      _RussianStrings() => 'РџСѓР±Р»РёС‡РЅРѕ',
      _ => 'Public',
    };
  }

  String get private {
    return switch (this) {
      _UzbekStrings() => 'Yopiq',
      _RussianStrings() => 'РџСЂРёРІР°С‚РЅРѕ',
      _ => 'Private',
    };
  }

  String get choosePhotoFirst {
    return switch (this) {
      _UzbekStrings() => 'Avval rasm tanlang.',
      _RussianStrings() => 'РЎРЅР°С‡Р°Р»Р° РІС‹Р±РµСЂРёС‚Рµ С„РѕС‚Рѕ.',
      _ => 'Choose a photo first.',
    };
  }

  String get observationLocation {
    return switch (this) {
      _UzbekStrings() => 'Kuzatuv joylashuvi',
      _RussianStrings() => 'РњРµСЃС‚Рѕ РЅР°Р±Р»СЋРґРµРЅРёСЏ',
      _ => 'Observation location',
    };
  }

  String get backToAdd {
    return switch (this) {
      _UzbekStrings() => 'QoК»shishga qaytish',
      _RussianStrings() => 'РќР°Р·Р°Рґ Рє РґРѕР±Р°РІР»РµРЅРёСЋ',
      _ => 'Back to Add',
    };
  }

  String get attachLocationQuestion {
    return switch (this) {
      _UzbekStrings() => 'Joylashuv biriktirilsinmi?',
      _RussianStrings() => 'РџСЂРёРєСЂРµРїРёС‚СЊ РјРµСЃС‚Рѕ?',
      _ => 'Attach a location?',
    };
  }

  String get attachLocationHelp {
    return switch (this) {
      _UzbekStrings() =>
        'Joylashuv kuzatuvni xaritada koК»rsatadi. Rasm eski boК»lsa yoki joy aniq boК»lmasa, oК»tkazib yuboring.',
      _RussianStrings() =>
        'РњРµСЃС‚Рѕ РґРµР»Р°РµС‚ РЅР°Р±Р»СЋРґРµРЅРёРµ РІРёРґРёРјС‹Рј РЅР° РєР°СЂС‚Рµ. РџСЂРѕРїСѓСЃС‚РёС‚Рµ РµРіРѕ, РµСЃР»Рё С„РѕС‚Рѕ СЃС‚Р°СЂРѕРµ РёР»Рё РјРµСЃС‚Рѕ РЅРµРёР·РІРµСЃС‚РЅРѕ.',
      _ =>
        'A location makes the observation visible on the map. Skip it if the photo is old or the place is uncertain.',
    };
  }

  String get useMyCurrentLocation {
    return switch (this) {
      _UzbekStrings() => 'Joriy joylashuvimdan foydalanish',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ РјРѕРµ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ',
      _ => 'Use my current location',
    };
  }

  String get markOnMap {
    return switch (this) {
      _UzbekStrings() => 'Xaritada belgilash',
      _RussianStrings() => 'РћС‚РјРµС‚РёС‚СЊ РЅР° РєР°СЂС‚Рµ',
      _ => 'Mark on map',
    };
  }

  String get continueWithoutLocation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuvsiz davom etish',
      _RussianStrings() => 'РџСЂРѕРґРѕР»Р¶РёС‚СЊ Р±РµР· РјРµСЃС‚Р°',
      _ => 'Continue without location',
    };
  }

  String get couldNotResolveYourLocation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuvingizni aniqlab boК»lmadi.',
      _RussianStrings() => 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕРїСЂРµРґРµР»РёС‚СЊ РІР°С€Рµ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ.',
      _ => 'Could not resolve your location.',
    };
  }

  String get useThisLocation {
    return switch (this) {
      _UzbekStrings() => 'Shu joylashuvdan foydalanish',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ СЌС‚Рѕ РјРµСЃС‚Рѕ',
      _ => 'Use this location',
    };
  }

  String get locatedObservation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuvli kuzatuv',
      _RussianStrings() => 'РќР°Р±Р»СЋРґРµРЅРёРµ СЃ РјРµСЃС‚РѕРј',
      _ => 'Located observation',
    };
  }

  String get feedOnlyPost {
    return switch (this) {
      _UzbekStrings() => 'Faqat lentadagi post',
      _RussianStrings() => 'РџРѕСЃС‚ С‚РѕР»СЊРєРѕ РІ Р»РµРЅС‚Рµ',
      _ => 'Feed-only post',
    };
  }

  String get changeLocation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuvni oК»zgartirish',
      _RussianStrings() => 'РР·РјРµРЅРёС‚СЊ РјРµСЃС‚Рѕ',
      _ => 'Change location',
    };
  }

  String get addLocation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuv qoК»shish',
      _RussianStrings() => 'Р”РѕР±Р°РІРёС‚СЊ РјРµСЃС‚Рѕ',
      _ => 'Add location',
    };
  }

  String get matchCatAndAddDetails {
    return switch (this) {
      _UzbekStrings() => 'Mushukni moslang va tafsilot qoК»shing',
      _RussianStrings() => 'РЎРѕРїРѕСЃС‚Р°РІСЊС‚Рµ РєРѕС€РєСѓ Рё РґРѕР±Р°РІСЊС‚Рµ РґРµС‚Р°Р»Рё',
      _ => 'Match the cat and add details',
    };
  }

  String get feedOnlyObservationHelp {
    return switch (this) {
      _UzbekStrings() =>
        'Bu galereya kuzatuvi faqat lentada chiqadi va xaritada marker yaratmaydi.',
      _RussianStrings() =>
        'Р­С‚Рѕ РЅР°Р±Р»СЋРґРµРЅРёРµ РёР· РіР°Р»РµСЂРµРё РїРѕСЏРІРёС‚СЃСЏ С‚РѕР»СЊРєРѕ РІ Р»РµРЅС‚Рµ Рё РЅРµ СЃРѕР·РґР°СЃС‚ РјР°СЂРєРµСЂ РЅР° РєР°СЂС‚Рµ.',
      _ =>
        'This gallery observation will appear in the feed only and will not create a map marker.',
    };
  }

  String get descriptionHint {
    return switch (this) {
      _UzbekStrings() =>
        'Mushuk, joylashuv va kerak boК»lishi mumkin boК»lgan yordamni tasvirlang',
      _RussianStrings() =>
        'РћРїРёС€РёС‚Рµ РєРѕС€РєСѓ, РјРµСЃС‚Рѕ Рё РїРѕРјРѕС‰СЊ, РєРѕС‚РѕСЂР°СЏ РјРѕР¶РµС‚ РїРѕРЅР°РґРѕР±РёС‚СЊСЃСЏ',
      _ => 'Describe the cat, location, and any help it may need',
    };
  }

  String get newCatNameOptional {
    return switch (this) {
      _UzbekStrings() => 'Yangi mushuk nomi (ixtiyoriy)',
      _RussianStrings() => 'РРјСЏ РЅРѕРІРѕР№ РєРѕС€РєРё (РЅРµРѕР±СЏР·Р°С‚РµР»СЊРЅРѕ)',
      _ => 'New cat name (optional)',
    };
  }

  String get unknown {
    return switch (this) {
      _UzbekStrings() => 'NomaКјlum',
      _RussianStrings() => 'РќРµРёР·РІРµСЃС‚РЅРѕ',
      _ => 'Unknown',
    };
  }

  String get healthy {
    return switch (this) {
      _UzbekStrings() => 'SogК»lom',
      _RussianStrings() => 'Р—РґРѕСЂРѕРІР°',
      _ => 'Healthy',
    };
  }

  String get catStatus {
    return switch (this) {
      _UzbekStrings() => 'Mushuk holati',
      _RussianStrings() => 'РЎРѕСЃС‚РѕСЏРЅРёРµ РєРѕС€РєРё',
      _ => 'Cat status',
    };
  }

  String get publishObservation {
    return switch (this) {
      _UzbekStrings() => 'Kuzatuvni joylash',
      _RussianStrings() => 'РћРїСѓР±Р»РёРєРѕРІР°С‚СЊ РЅР°Р±Р»СЋРґРµРЅРёРµ',
      _ => 'Publish observation',
    };
  }

  String get nearbyCats {
    return switch (this) {
      _UzbekStrings() => 'Yaqindagi mushuklar',
      _RussianStrings() => 'РљРѕС€РєРё СЂСЏРґРѕРј',
      _ => 'Nearby cats',
    };
  }

  String get noNearbyCatsFound {
    return switch (this) {
      _UzbekStrings() => 'Yaqinda mushuk topilmadi.',
      _RussianStrings() => 'РљРѕС€РµРє СЂСЏРґРѕРј РЅРµ РЅР°Р№РґРµРЅРѕ.',
      _ => 'No nearby cats found.',
    };
  }

  String get thisIsNewCat {
    return switch (this) {
      _UzbekStrings() => 'Bu yangi mushuk',
      _RussianStrings() => 'Р­С‚Рѕ РЅРѕРІР°СЏ РєРѕС€РєР°',
      _ => 'This is a new cat',
    };
  }

  String get published {
    return switch (this) {
      _UzbekStrings() => 'Joylandi',
      _RussianStrings() => 'РћРїСѓР±Р»РёРєРѕРІР°РЅРѕ',
      _ => 'Published',
    };
  }

  String get observationPublished {
    return switch (this) {
      _UzbekStrings() => 'Kuzatuv joylandi.',
      _RussianStrings() => 'РќР°Р±Р»СЋРґРµРЅРёРµ РѕРїСѓР±Р»РёРєРѕРІР°РЅРѕ.',
      _ => 'Observation published.',
    };
  }

  String postNowAvailable(String id) {
    return switch (this) {
      _UzbekStrings() => '$id posti endi lentada mavjud.',
      _RussianStrings() => 'РџРѕСЃС‚ $id С‚РµРїРµСЂСЊ РґРѕСЃС‚СѓРїРµРЅ РІ Р»РµРЅС‚Рµ.',
      _ => 'Post $id is now available in the feed.',
    };
  }

  String get observationSentToBackend {
    return switch (this) {
      _UzbekStrings() => 'Kuzatuvingiz backendga yuborildi.',
      _RussianStrings() => 'Р’Р°С€Рµ РЅР°Р±Р»СЋРґРµРЅРёРµ РѕС‚РїСЂР°РІР»РµРЅРѕ РЅР° backend.',
      _ => 'Your observation has been sent to the backend.',
    };
  }

  String get viewFeed {
    return switch (this) {
      _UzbekStrings() => 'Lentani koК»rish',
      _RussianStrings() => 'РћС‚РєСЂС‹С‚СЊ Р»РµРЅС‚Сѓ',
      _ => 'View feed',
    };
  }

  String get addAnother {
    return switch (this) {
      _UzbekStrings() => 'Yana qoК»shish',
      _RussianStrings() => 'Р”РѕР±Р°РІРёС‚СЊ РµС‰Рµ',
      _ => 'Add another',
    };
  }

  String addPhotosCount(int count) {
    return switch (this) {
      _UzbekStrings() => 'Rasm qoК»shish ($count/5)',
      _RussianStrings() => 'Р”РѕР±Р°РІРёС‚СЊ С„РѕС‚Рѕ ($count/5)',
      _ => 'Add photos ($count/5)',
    };
  }

  String get rehoming {
    return switch (this) {
      _UzbekStrings() => 'Uy topish',
      _RussianStrings() => 'РџСЂРёСЃС‚СЂРѕР№СЃС‚РІРѕ',
      _ => 'Rehoming',
    };
  }

  String get createRehomingPost {
    return switch (this) {
      _UzbekStrings() => 'Uy topish postini yaratish',
      _RussianStrings() => 'РЎРѕР·РґР°С‚СЊ РїРѕСЃС‚ Рѕ РїСЂРёСЃС‚СЂРѕР№СЃС‚РІРµ',
      _ => 'Create a rehoming post',
    };
  }

  String get createRehomingPostHelp {
    return switch (this) {
      _UzbekStrings() =>
        'Mushuk va unga qanday uy kerakligini tasvirlang. Bu yoК»qolgan jonivor eКјlonlaridan alohida va xarita joylashuvini talab qilmaydi.',
      _RussianStrings() =>
        'РћРїРёС€РёС‚Рµ РєРѕС€РєСѓ Рё РєР°РєРѕР№ РґРѕРј РµР№ РЅСѓР¶РµРЅ. Р­С‚Рѕ РѕС‚РґРµР»СЊРЅРѕ РѕС‚ РѕР±СЉСЏРІР»РµРЅРёР№ Рѕ РїРѕС‚РµСЂСЏРЅРЅС‹С… РїРёС‚РѕРјС†Р°С… Рё РЅРµ С‚СЂРµР±СѓРµС‚ РјРµСЃС‚Р° РЅР° РєР°СЂС‚Рµ.',
      _ =>
        'Describe the cat and the kind of home they need. This is separate from lost-pet alerts and does not require a map location.',
    };
  }

  String get petName {
    return switch (this) {
      _UzbekStrings() => 'Jonivor nomi',
      _RussianStrings() => 'РРјСЏ РїРёС‚РѕРјС†Р°',
      _ => "Pet's name",
    };
  }

  String get petNameRequired {
    return switch (this) {
      _UzbekStrings() => 'Jonivor nomini kiriting.',
      _RussianStrings() => 'Р’РІРµРґРёС‚Рµ РёРјСЏ РїРёС‚РѕРјС†Р°.',
      _ => "Enter the pet's name.",
    };
  }

  String get additionalInformation {
    return switch (this) {
      _UzbekStrings() => 'QoК»shimcha maКјlumot',
      _RussianStrings() => 'Р”РѕРїРѕР»РЅРёС‚РµР»СЊРЅР°СЏ РёРЅС„РѕСЂРјР°С†РёСЏ',
      _ => 'Additional information',
    };
  }

  String get adoptionInfoHint {
    return switch (this) {
      _UzbekStrings() =>
        'Yoshi, xarakteri, salomatligi va qanday uy maКјqul.',
      _RussianStrings() =>
        'Р’РѕР·СЂР°СЃС‚, С…Р°СЂР°РєС‚РµСЂ, Р·РґРѕСЂРѕРІСЊРµ Рё РїСЂРµРґРїРѕС‡С‚РёС‚РµР»СЊРЅС‹Р№ РґРѕРј.',
      _ => 'Age, personality, health notes, and preferred home.',
    };
  }

  String get showPhonePublicly {
    return switch (this) {
      _UzbekStrings() => 'Telefon raqamim ochiq koК»rsatilsin',
      _RussianStrings() => 'РџРѕРєР°Р·С‹РІР°С‚СЊ РјРѕР№ РЅРѕРјРµСЂ С‚РµР»РµС„РѕРЅР° РїСѓР±Р»РёС‡РЅРѕ',
      _ => 'Show my phone number publicly',
    };
  }

  String get adoptionPhoneHelp {
    return switch (this) {
      _UzbekStrings() =>
        'Odamlar asrab olish haqida bogК»lanishi uchun profilingizdagi telefon raqami kerak.',
      _RussianStrings() =>
        'Р›СЋРґСЏРј РЅСѓР¶РµРЅ С‚РµР»РµС„РѕРЅ РёР· РІР°С€РµРіРѕ РїСЂРѕС„РёР»СЏ, С‡С‚РѕР±С‹ СЃРІСЏР·Р°С‚СЊСЃСЏ РїРѕ РїРѕРІРѕРґСѓ РїСЂРёСЃС‚СЂРѕР№СЃС‚РІР°.',
      _ =>
        'People need your profile phone number to contact you about adoption.',
    };
  }

  String get addAtLeastOnePhoto {
    return switch (this) {
      _UzbekStrings() => 'Kamida bitta rasm qoК»shing.',
      _RussianStrings() => 'Р”РѕР±Р°РІСЊС‚Рµ С…РѕС‚СЏ Р±С‹ РѕРґРЅРѕ С„РѕС‚Рѕ.',
      _ => 'Add at least one photo.',
    };
  }

  String get confirmPhonePublic {
    return switch (this) {
      _UzbekStrings() =>
        'Telefon raqamingiz ochiq koК»rsatilishini tasdiqlang.',
      _RussianStrings() =>
        'РџРѕРґС‚РІРµСЂРґРёС‚Рµ, С‡С‚Рѕ РІР°С€ РЅРѕРјРµСЂ С‚РµР»РµС„РѕРЅР° РјРѕР¶РЅРѕ РїРѕРєР°Р·Р°С‚СЊ РїСѓР±Р»РёС‡РЅРѕ.',
      _ => 'Confirm that your phone number may be shown publicly.',
    };
  }

  String get publishAdoptionPost {
    return switch (this) {
      _UzbekStrings() => 'Asrab olish postini joylash',
      _RussianStrings() => 'РћРїСѓР±Р»РёРєРѕРІР°С‚СЊ РїРѕСЃС‚ Рѕ РїСЂРёСЃС‚СЂРѕР№СЃС‚РІРµ',
      _ => 'Publish adoption post',
    };
  }

  String get adoption {
    return switch (this) {
      _UzbekStrings() => 'Asrab olish',
      _RussianStrings() => 'РџСЂРёСЃС‚СЂРѕР№СЃС‚РІРѕ',
      _ => 'Adoption',
    };
  }

  String get addComment {
    return switch (this) {
      _UzbekStrings() => 'Izoh qoК»shish',
      _RussianStrings() => 'Р”РѕР±Р°РІРёС‚СЊ РєРѕРјРјРµРЅС‚Р°СЂРёР№',
      _ => 'Add a comment',
    };
  }

  String get postComment {
    return switch (this) {
      _UzbekStrings() => 'Izohni joylash',
      _RussianStrings() => 'РћРїСѓР±Р»РёРєРѕРІР°С‚СЊ РєРѕРјРјРµРЅС‚Р°СЂРёР№',
      _ => 'Post comment',
    };
  }

  String get hide {
    return switch (this) {
      _UzbekStrings() => 'Yashirish',
      _RussianStrings() => 'РЎРєСЂС‹С‚СЊ',
      _ => 'Hide',
    };
  }

  String get noPublicPostFoundForCat {
    return switch (this) {
      _UzbekStrings() => 'Bu mushuk uchun ochiq post topilmadi.',
      _RussianStrings() => 'РџСѓР±Р»РёС‡РЅС‹Р№ РїРѕСЃС‚ РґР»СЏ СЌС‚РѕР№ РєРѕС€РєРё РЅРµ РЅР°Р№РґРµРЅ.',
      _ => 'No public post found for this cat.',
    };
  }

  String couldNotOpenPost(Object error) {
    return switch (this) {
      _UzbekStrings() => 'Postni ochib boК»lmadi: $error',
      _RussianStrings() => 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РєСЂС‹С‚СЊ РїРѕСЃС‚: $error',
      _ => 'Could not open post: $error',
    };
  }

  String get useMyLocation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuvimdan foydalanish',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ РјРѕРµ РјРµСЃС‚Рѕ',
      _ => 'Use my location',
    };
  }

  String get observation {
    return switch (this) {
      _UzbekStrings() => 'Kuzatuv',
      _RussianStrings() => 'РќР°Р±Р»СЋРґРµРЅРёРµ',
      _ => 'Observation',
    };
  }

  String get report {
    return switch (this) {
      _UzbekStrings() => 'Shikoyat qilish',
      _RussianStrings() => 'РџРѕР¶Р°Р»РѕРІР°С‚СЊСЃСЏ',
      _ => 'Report',
    };
  }

  String get changeProfilePicture {
    return switch (this) {
      _UzbekStrings() => 'Profil rasmini oК»zgartirish',
      _RussianStrings() => 'РР·РјРµРЅРёС‚СЊ С„РѕС‚Рѕ РїСЂРѕС„РёР»СЏ',
      _ => 'Change profile picture',
    };
  }

  String get useCamera {
    return switch (this) {
      _UzbekStrings() => 'Kameradan foydalanish',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ РєР°РјРµСЂСѓ',
      _ => 'Use camera',
    };
  }

  String get telegramUsername {
    return switch (this) {
      _UzbekStrings() => 'Telegram username',
      _RussianStrings() => 'РРјСЏ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ Telegram',
      _ => 'Telegram username',
    };
  }

  String get bio {
    return switch (this) {
      _UzbekStrings() => 'Bio',
      _RussianStrings() => 'Рћ СЃРµР±Рµ',
      _ => 'Bio',
    };
  }

  String get bioHint {
    return switch (this) {
      _UzbekStrings() => 'Toshkentdan Aydos, mushuklarni yaxshi koК»radi',
      _RussianStrings() => 'РђР№РґРѕСЃ РёР· РўР°С€РєРµРЅС‚Р°, Р»СЋР±РёС‚ РєРѕС€РµРє',
      _ => 'Aydos from Tashkent, cat lover',
    };
  }

  String get uzbekPhoneFormatHelp {
    return switch (this) {
      _UzbekStrings() => 'OК»zbekiston formati: +998 xx xxx xx xx',
      _RussianStrings() => 'Р¤РѕСЂРјР°С‚ РЈР·Р±РµРєРёСЃС‚Р°РЅР°: +998 xx xxx xx xx',
      _ => 'Uzbekistan format: +998 xx xxx xx xx',
    };
  }

  String get telegramValidation {
    return switch (this) {
      _UzbekStrings() =>
        '5-32 ta harf, raqam yoki pastki chiziqdan foydalaning.',
      _RussianStrings() =>
        'РСЃРїРѕР»СЊР·СѓР№С‚Рµ 5-32 Р±СѓРєРІС‹, С†РёС„СЂС‹ РёР»Рё РЅРёР¶РЅРёРµ РїРѕРґС‡РµСЂРєРёРІР°РЅРёСЏ.',
      _ => 'Use 5-32 letters, numbers, or underscores.',
    };
  }

  String get profileNotFound {
    return switch (this) {
      _UzbekStrings() => 'Profil topilmadi.',
      _RussianStrings() => 'РџСЂРѕС„РёР»СЊ РЅРµ РЅР°Р№РґРµРЅ.',
      _ => 'Profile not found.',
    };
  }

  String get blockUser {
    return switch (this) {
      _UzbekStrings() => 'Foydalanuvchini bloklash',
      _RussianStrings() => 'Р—Р°Р±Р»РѕРєРёСЂРѕРІР°С‚СЊ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ',
      _ => 'Block user',
    };
  }

  String get userBlocked {
    return switch (this) {
      _UzbekStrings() => 'Foydalanuvchi bloklandi.',
      _RussianStrings() => 'РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ Р·Р°Р±Р»РѕРєРёСЂРѕРІР°РЅ.',
      _ => 'User blocked.',
    };
  }

  String get blockUserTitle {
    return switch (this) {
      _UzbekStrings() => 'Foydalanuvchi bloklansinmi?',
      _RussianStrings() => 'Р—Р°Р±Р»РѕРєРёСЂРѕРІР°С‚СЊ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ?',
      _ => 'Block user?',
    };
  }

  String get blockUserMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Foydalanuvchi haqoratli yoki xavfli boК»lsa, shundan foydalaning. Blokdan chiqarish interfeysi qoК»shilguncha supportdan yordam soК»rashingiz mumkin.',
      _RussianStrings() =>
        'РСЃРїРѕР»СЊР·СѓР№С‚Рµ СЌС‚Рѕ, РµСЃР»Рё РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ РІРµРґРµС‚ СЃРµР±СЏ РѕСЃРєРѕСЂР±РёС‚РµР»СЊРЅРѕ РёР»Рё РЅРµР±РµР·РѕРїР°СЃРЅРѕ. РџРѕРєР° РёРЅС‚РµСЂС„РµР№СЃ СЂР°Р·Р±Р»РѕРєРёСЂРѕРІРєРё РЅРµ РґРѕР±Р°РІР»РµРЅ, РјРѕР¶РЅРѕ РїРѕРїСЂРѕСЃРёС‚СЊ support СЂР°Р·Р±Р»РѕРєРёСЂРѕРІР°С‚СЊ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ.',
      _ =>
        'Use this when a user is abusive or unsafe. You can ask support to unblock them until the unblock UI is added.',
    };
  }

  String get block {
    return switch (this) {
      _UzbekStrings() => 'Bloklash',
      _RussianStrings() => 'Р—Р°Р±Р»РѕРєРёСЂРѕРІР°С‚СЊ',
      _ => 'Block',
    };
  }

  String get englishLanguage {
    return switch (this) {
      _UzbekStrings() => 'Inglizcha',
      _RussianStrings() => 'РђРЅРіР»РёР№СЃРєРёР№',
      _ => 'English',
    };
  }

  String get uzbekLanguage {
    return switch (this) {
      _UzbekStrings() => 'OК»zbekcha',
      _RussianStrings() => 'РЈР·Р±РµРєСЃРєРёР№',
      _ => 'Uzbek',
    };
  }

  String get russianLanguage {
    return switch (this) {
      _UzbekStrings() => 'Ruscha',
      _RussianStrings() => 'Р СѓСЃСЃРєРёР№',
      _ => 'Russian',
    };
  }

  String get confirmingEmail {
    return switch (this) {
      _UzbekStrings() => 'Email tasdiqlanmoqda...',
      _RussianStrings() => 'Email РїРѕРґС‚РІРµСЂР¶РґР°РµС‚СЃСЏ...',
      _ => 'Confirming your email...',
    };
  }

  String get emailVerifiedSignInNow {
    return switch (this) {
      _UzbekStrings() => 'Email tasdiqlandi. Endi kirishingiz mumkin.',
      _RussianStrings() => 'Email РїРѕРґС‚РІРµСЂР¶РґРµРЅ. РўРµРїРµСЂСЊ РјРѕР¶РЅРѕ РІРѕР№С‚Рё.',
      _ => 'Email verified. You can sign in now.',
    };
  }

  String get couldNotVerifyEmailLink {
    return switch (this) {
      _UzbekStrings() => 'Bu email havolasini tasdiqlab boК»lmadi.',
      _RussianStrings() => 'РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕРґС‚РІРµСЂРґРёС‚СЊ СЌС‚Сѓ СЃСЃС‹Р»РєСѓ email.',
      _ => 'Could not verify this email link.',
    };
  }

  String get googleSignInNoIdToken {
    return switch (this) {
      _UzbekStrings() => 'Google kirishi ID token qaytarmadi.',
      _RussianStrings() => 'Р’С…РѕРґ С‡РµСЂРµР· Google РЅРµ РІРµСЂРЅСѓР» ID token.',
      _ => 'Google sign-in did not return an ID token.',
    };
  }

  String get googleSignInFailed {
    return switch (this) {
      _UzbekStrings() => 'Google orqali kirish amalga oshmadi.',
      _RussianStrings() => 'РќРµ СѓРґР°Р»РѕСЃСЊ РІРѕР№С‚Рё С‡РµСЂРµР· Google.',
      _ => 'Google sign-in failed.',
    };
  }

  String get googleSignInNotConfigured {
    return switch (this) {
      _UzbekStrings() =>
        'Bu build uchun Google orqali kirish sozlanmagan.',
      _RussianStrings() =>
        'Р’С…РѕРґ С‡РµСЂРµР· Google РЅРµ РЅР°СЃС‚СЂРѕРµРЅ РґР»СЏ СЌС‚РѕР№ СЃР±РѕСЂРєРё.',
      _ => 'Google sign-in is not configured for this build.',
    };
  }

  String get googleSignInUnavailable {
    return switch (this) {
      _UzbekStrings() => 'Google orqali kirish hozir mavjud emas.',
      _RussianStrings() => 'Р’С…РѕРґ С‡РµСЂРµР· Google СЃРµР№С‡Р°СЃ РЅРµРґРѕСЃС‚СѓРїРµРЅ.',
      _ => 'Google sign-in is unavailable.',
    };
  }

  String get landOfCats {
    return switch (this) {
      _UzbekStrings() => 'Mushuklar yurti',
      _RussianStrings() => 'РЎС‚СЂР°РЅР° РєРѕС€РµРє',
      _ => 'The land of cats',
    };
  }

  String get everythingCatsTitle {
    return switch (this) {
      _UzbekStrings() => 'Mushuklarga oid hammasi bir sokin joyda',
      _RussianStrings() => 'Р’СЃРµ Рѕ РєРѕС€РєР°С… РІ РѕРґРЅРѕРј СЃРїРѕРєРѕР№РЅРѕРј РјРµСЃС‚Рµ',
      _ => 'Everything cats in one calm place',
    };
  }

  String get everythingCatsMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Kuzatuvlarni ulashing, yordam kerak mushuklarni belgilang, yoК»qolgan jonivorlarni qidiring, mushuklarga yangi uy toping va yaqin foydali joylarni toping.',
      _RussianStrings() =>
        'Р”РµР»РёС‚РµСЃСЊ РЅР°Р±Р»СЋРґРµРЅРёСЏРјРё, РѕС‚РјРµС‡Р°Р№С‚Рµ РєРѕС€РµРє, РєРѕС‚РѕСЂС‹Рј РЅСѓР¶РЅР° РїРѕРјРѕС‰СЊ, РёС‰РёС‚Рµ РїРѕС‚РµСЂСЏРЅРЅС‹С… РїРёС‚РѕРјС†РµРІ, РїСЂРёСЃС‚СЂР°РёРІР°Р№С‚Рµ РєРѕС€РµРє Рё РЅР°С…РѕРґРёС‚Рµ РїРѕР»РµР·РЅС‹Рµ РјРµСЃС‚Р° СЂСЏРґРѕРј.',
      _ =>
        'Share sightings, tag observations as Needs help for cats in need, search for lost pets, rehome cats, and discover useful places nearby.',
    };
  }

  String get urgentAlerts {
    return switch (this) {
      _UzbekStrings() => 'Shoshilinch eКјlonlar',
      _RussianStrings() => 'РЎСЂРѕС‡РЅС‹Рµ РѕР±СЉСЏРІР»РµРЅРёСЏ',
      _ => 'Urgent alerts',
    };
  }

  String get newHomes {
    return switch (this) {
      _UzbekStrings() => 'Yangi uylar',
      _RussianStrings() => 'РќРѕРІС‹Рµ РґРѕРјР°',
      _ => 'New homes',
    };
  }

  String get adoptionPosts {
    return switch (this) {
      _UzbekStrings() => 'Asrab olish postlari',
      _RussianStrings() => 'РџРѕСЃС‚С‹ Рѕ РїСЂРёСЃС‚СЂРѕР№СЃС‚РІРµ',
      _ => 'Adoption posts',
    };
  }

  String get usefulPlaces {
    return switch (this) {
      _UzbekStrings() => 'Foydali joylar',
      _RussianStrings() => 'РџРѕР»РµР·РЅС‹Рµ РјРµСЃС‚Р°',
      _ => 'Useful places',
    };
  }

  String get vetsShopsShelters {
    return switch (this) {
      _UzbekStrings() => 'Veterinarlar, doК»konlar, shelterlar',
      _RussianStrings() => 'Р’РµС‚РєР»РёРЅРёРєРё, РјР°РіР°Р·РёРЅС‹, РїСЂРёСЋС‚С‹',
      _ => 'Vets, shops, shelters',
    };
  }

  String get nearbyMap {
    return switch (this) {
      _UzbekStrings() => 'Yaqin xarita',
      _RussianStrings() => 'РљР°СЂС‚Р° СЂСЏРґРѕРј',
      _ => 'Nearby map',
    };
  }

  String get catsAndServices {
    return switch (this) {
      _UzbekStrings() => 'Mushuklar va xizmatlar',
      _RussianStrings() => 'РљРѕС€РєРё Рё СЃРµСЂРІРёСЃС‹',
      _ => 'Cats and services',
    };
  }

  String get useYourLocation {
    return switch (this) {
      _UzbekStrings() => 'Joylashuvingizdan foydalanish',
      _RussianStrings() => 'РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ РІР°С€Рµ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ',
      _ => 'Use your location',
    };
  }

  String get locationDisclosureMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Mushukistan yaqin mushuklar va foydali joylarni koК»rsatish uchun joriy joylashuvingizdan foydalanadi. Ochiq post yaratmasangiz, u joylanmaydi.',
      _RussianStrings() =>
        'Mushukistan РёСЃРїРѕР»СЊР·СѓРµС‚ РІР°С€Рµ С‚РµРєСѓС‰РµРµ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ, С‡С‚РѕР±С‹ РїРѕРєР°Р·С‹РІР°С‚СЊ РєРѕС€РµРє Рё РїРѕР»РµР·РЅС‹Рµ РјРµСЃС‚Р° СЂСЏРґРѕРј. РћРЅРѕ РЅРµ РїСѓР±Р»РёРєСѓРµС‚СЃСЏ, РµСЃР»Рё РІС‹ РЅРµ СЃРѕР·РґР°РґРёС‚Рµ РїСѓР±Р»РёС‡РЅС‹Р№ РїРѕСЃС‚.',
      _ =>
        'Mushukistan uses your current location to show nearby cats and useful places. It is not published unless you create a public post.',
    };
  }

  String get feedStatus {
    return switch (this) {
      _UzbekStrings() => 'Lenta',
      _RussianStrings() => 'Р›РµРЅС‚Р°',
      _ => 'Feed',
    };
  }

  String get moderationReports {
    return switch (this) {
      _UzbekStrings() => 'Moderatsiya shikoyatlari',
      _RussianStrings() => 'Р–Р°Р»РѕР±С‹ РјРѕРґРµСЂР°С†РёРё',
      _ => 'Moderation reports',
    };
  }

  String get noOpenReports {
    return switch (this) {
      _UzbekStrings() => 'Ochiq shikoyatlar yoК»q.',
      _RussianStrings() => 'РћС‚РєСЂС‹С‚С‹С… Р¶Р°Р»РѕР± РЅРµС‚.',
      _ => 'No open reports.',
    };
  }

  String get noReasonProvided {
    return switch (this) {
      _UzbekStrings() => 'Sabab kiritilmagan.',
      _RussianStrings() => 'РџСЂРёС‡РёРЅР° РЅРµ СѓРєР°Р·Р°РЅР°.',
      _ => 'No reason provided.',
    };
  }

  String get reportDetail {
    return switch (this) {
      _UzbekStrings() => 'Shikoyat tafsiloti',
      _RussianStrings() => 'Р”РµС‚Р°Р»Рё Р¶Р°Р»РѕР±С‹',
      _ => 'Report detail',
    };
  }

  String targetId(String id) {
    return switch (this) {
      _UzbekStrings() => 'Nishon ID: $id',
      _RussianStrings() => 'ID РѕР±СЉРµРєС‚Р°: $id',
      _ => 'Target ID: $id',
    };
  }

  String targetTitle(String title) {
    return switch (this) {
      _UzbekStrings() => 'Sarlavha: $title',
      _RussianStrings() => 'Р—Р°РіРѕР»РѕРІРѕРє: $title',
      _ => 'Title: $title',
    };
  }

  String targetStatus(String status) {
    return switch (this) {
      _UzbekStrings() => 'Holat: $status',
      _RussianStrings() => 'РЎС‚Р°С‚СѓСЃ: $status',
      _ => 'Status: $status',
    };
  }

  String get resolve {
    return switch (this) {
      _UzbekStrings() => 'Hal qilish',
      _RussianStrings() => 'Р РµС€РёС‚СЊ',
      _ => 'Resolve',
    };
  }

  String get dismiss {
    return switch (this) {
      _UzbekStrings() => 'Rad etish',
      _RussianStrings() => 'РћС‚РєР»РѕРЅРёС‚СЊ',
      _ => 'Dismiss',
    };
  }

  String get reportStatus {
    return switch (this) {
      _UzbekStrings() => 'Shikoyat holati',
      _RussianStrings() => 'РЎС‚Р°С‚СѓСЃ Р¶Р°Р»РѕР±С‹',
      _ => 'Report status',
    };
  }

  String get noAction {
    return switch (this) {
      _UzbekStrings() => 'Amal yoК»q',
      _RussianStrings() => 'Р‘РµР· РґРµР№СЃС‚РІРёСЏ',
      _ => 'No action',
    };
  }

  String get softDeletePost {
    return switch (this) {
      _UzbekStrings() => 'Postni yashirib oК»chirish',
      _RussianStrings() => 'РњСЏРіРєРѕ СѓРґР°Р»РёС‚СЊ РїРѕСЃС‚',
      _ => 'Soft delete post',
    };
  }

  String get softDeleteComment {
    return switch (this) {
      _UzbekStrings() => 'Izohni yashirib oК»chirish',
      _RussianStrings() => 'РњСЏРіРєРѕ СѓРґР°Р»РёС‚СЊ РєРѕРјРјРµРЅС‚Р°СЂРёР№',
      _ => 'Soft delete comment',
    };
  }

  String get suspendUser {
    return switch (this) {
      _UzbekStrings() => 'Foydalanuvchini toК»xtatish',
      _RussianStrings() => 'Р—Р°Р±Р»РѕРєРёСЂРѕРІР°С‚СЊ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ',
      _ => 'Suspend user',
    };
  }

  String get moderationAction {
    return switch (this) {
      _UzbekStrings() => 'Moderatsiya amali',
      _RussianStrings() => 'Р”РµР№СЃС‚РІРёРµ РјРѕРґРµСЂР°С†РёРё',
      _ => 'Moderation action',
    };
  }

  String get note {
    return switch (this) {
      _UzbekStrings() => 'Eslatma',
      _RussianStrings() => 'Р—Р°РјРµС‚РєР°',
      _ => 'Note',
    };
  }

  String get saveModerationDecision {
    return switch (this) {
      _UzbekStrings() => 'Moderatsiya qarorini saqlash',
      _RussianStrings() => 'РЎРѕС…СЂР°РЅРёС‚СЊ СЂРµС€РµРЅРёРµ РјРѕРґРµСЂР°С†РёРё',
      _ => 'Save moderation decision',
    };
  }

  String get reportContent {
    return switch (this) {
      _UzbekStrings() => 'Kontentdan shikoyat qilish',
      _RussianStrings() => 'РџРѕР¶Р°Р»РѕРІР°С‚СЊСЃСЏ РЅР° РєРѕРЅС‚РµРЅС‚',
      _ => 'Report content',
    };
  }

  String get post {
    return switch (this) {
      _UzbekStrings() => 'Post',
      _RussianStrings() => 'РџРѕСЃС‚',
      _ => 'Post',
    };
  }

  String get comment {
    return switch (this) {
      _UzbekStrings() => 'Izoh',
      _RussianStrings() => 'РљРѕРјРјРµРЅС‚Р°СЂРёР№',
      _ => 'Comment',
    };
  }

  String get user {
    return switch (this) {
      _UzbekStrings() => 'Foydalanuvchi',
      _RussianStrings() => 'РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ',
      _ => 'User',
    };
  }

  String get cat {
    return switch (this) {
      _UzbekStrings() => 'Mushuk',
      _RussianStrings() => 'РљРѕС€РєР°',
      _ => 'Cat',
    };
  }

  String get targetType {
    return switch (this) {
      _UzbekStrings() => 'Nishon turi',
      _RussianStrings() => 'РўРёРї РѕР±СЉРµРєС‚Р°',
      _ => 'Target type',
    };
  }

  String get targetIdLabel {
    return switch (this) {
      _UzbekStrings() => 'Nishon ID',
      _RussianStrings() => 'ID РѕР±СЉРµРєС‚Р°',
      _ => 'Target ID',
    };
  }

  String get targetIdRequired {
    return switch (this) {
      _UzbekStrings() => 'Nishon ID kiritilishi kerak.',
      _RussianStrings() => 'РЈРєР°Р¶РёС‚Рµ ID РѕР±СЉРµРєС‚Р°.',
      _ => 'Target ID is required.',
    };
  }

  String get reason {
    return switch (this) {
      _UzbekStrings() => 'Sabab',
      _RussianStrings() => 'РџСЂРёС‡РёРЅР°',
      _ => 'Reason',
    };
  }

  String get reasonRequired {
    return switch (this) {
      _UzbekStrings() => 'Iltimos, sababni kiriting.',
      _RussianStrings() => 'РџРѕР¶Р°Р»СѓР№СЃС‚Р°, СѓРєР°Р¶РёС‚Рµ РїСЂРёС‡РёРЅСѓ.',
      _ => 'Please provide a reason.',
    };
  }

  String get reportSubmitted {
    return switch (this) {
      _UzbekStrings() => 'Shikoyat yuborildi.',
      _RussianStrings() => 'Р–Р°Р»РѕР±Р° РѕС‚РїСЂР°РІР»РµРЅР°.',
      _ => 'Report submitted.',
    };
  }

  String get submitReport {
    return switch (this) {
      _UzbekStrings() => 'Shikoyatni yuborish',
      _RussianStrings() => 'РћС‚РїСЂР°РІРёС‚СЊ Р¶Р°Р»РѕР±Сѓ',
      _ => 'Submit report',
    };
  }

  String get catNameLabel {
    return switch (this) {
      _UzbekStrings() => 'Mushuk nomi',
      _RussianStrings() => '\u0418\u043c\u044f \u043a\u043e\u0448\u043a\u0438',
      _ => 'Cat name',
    };
  }

  String get descriptionLabel {
    return switch (this) {
      _UzbekStrings() => 'Tavsif',
      _RussianStrings() => '\u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435',
      _ => 'Description',
    };
  }

  String get lostPetSubtitle {
    return switch (this) {
      _UzbekStrings() =>
        'Rasmlar va egasining aloqa raqami bilan yoвЂqolgan mushukni joylang.',
      _RussianStrings() =>
        'РћРїСѓР±Р»РёРєСѓР№С‚Рµ РїРѕС‚РµСЂСЏРЅРЅСѓСЋ РєРѕС€РєСѓ СЃ С„РѕС‚Рѕ Рё РєРѕРЅС‚Р°РєС‚РѕРј РІР»Р°РґРµР»СЊС†Р°.',
      _ => 'Post a lost cat with photos and owner contact.',
    };
  }

  String get phoneNumberRequired {
    return switch (this) {
      _UzbekStrings() => 'Telefon raqami kerak',
      _RussianStrings() => 'РќСѓР¶РµРЅ РЅРѕРјРµСЂ С‚РµР»РµС„РѕРЅР°',
      _ => 'Phone number required',
    };
  }

  String get phoneNumberRequiredForLostPet {
    return switch (this) {
      _UzbekStrings() =>
        'YoвЂqolgan jonivorni joylashdan oldin toвЂgвЂri OвЂzbekiston telefon raqamini qoвЂshing. Masalan: +998 99 142 1314.',
      _RussianStrings() =>
        'Р”РѕР±Р°РІСЊС‚Рµ РєРѕСЂСЂРµРєС‚РЅС‹Р№ РЅРѕРјРµСЂ С‚РµР»РµС„РѕРЅР° РЈР·Р±РµРєРёСЃС‚Р°РЅР° РїРµСЂРµРґ РїСѓР±Р»РёРєР°С†РёРµР№ РїРѕС‚РµСЂСЏРЅРЅРѕРіРѕ РїРёС‚РѕРјС†Р°. РќР°РїСЂРёРјРµСЂ: +998 99 142 1314.',
      _ =>
        'Add a valid Uzbekistan phone number before posting a lost pet. Example: +998 99 142 1314.',
    };
  }

  String get photos {
    return switch (this) {
      _UzbekStrings() => 'Rasmlar',
      _RussianStrings() => 'Р¤РѕС‚Рѕ',
      _ => 'Photos',
    };
  }

  String get addPhotos {
    return switch (this) {
      _UzbekStrings() => 'Rasm qoвЂshish',
      _RussianStrings() => 'Р”РѕР±Р°РІРёС‚СЊ С„РѕС‚Рѕ',
      _ => 'Add photos',
    };
  }

  String get petsName {
    return switch (this) {
      _UzbekStrings() => 'Jonivorning ismi',
      _RussianStrings() => 'РРјСЏ РїРёС‚РѕРјС†Р°',
      _ => "Pet's name",
    };
  }

  String get enterPetsName {
    return switch (this) {
      _UzbekStrings() => 'Jonivorning ismini kiriting.',
      _RussianStrings() => 'Р’РІРµРґРёС‚Рµ РёРјСЏ РїРёС‚РѕРјС†Р°.',
      _ => "Enter the pet's name.",
    };
  }

  String get lastSeen {
    return switch (this) {
      _UzbekStrings() => 'Oxirgi koвЂrilgan joy',
      _RussianStrings() => 'Р“РґРµ РІРёРґРµР»Рё РІ РїРѕСЃР»РµРґРЅРёР№ СЂР°Р·',
      _ => 'Last seen',
    };
  }

  String get publishLostPet {
    return switch (this) {
      _UzbekStrings() => 'YoвЂqolgan jonivorni joylash',
      _RussianStrings() => 'РћРїСѓР±Р»РёРєРѕРІР°С‚СЊ РїРѕС‚РµСЂСЏРЅРЅРѕРіРѕ РїРёС‚РѕРјС†Р°',
      _ => 'Publish lost pet',
    };
  }

  String get pointLastSeenLocation {
    return switch (this) {
      _UzbekStrings() => 'Xaritada oxirgi koвЂrilgan joyni belgilang.',
      _RussianStrings() =>
        'РЈРєР°Р¶РёС‚Рµ РЅР° РєР°СЂС‚Рµ, РіРґРµ РїРёС‚РѕРјС†Р° РІРёРґРµР»Рё РІ РїРѕСЃР»РµРґРЅРёР№ СЂР°Р·.',
      _ => 'Point the last-seen location on the map.',
    };
  }

  String get phonePublicConsent {
    return switch (this) {
      _UzbekStrings() =>
        'Profilimdagi telefon raqamini bu yoвЂqolgan jonivor postida ochiq koвЂrsatish.',
      _RussianStrings() =>
        'РџСѓР±Р»РёС‡РЅРѕ РїРѕРєР°Р·Р°С‚СЊ РЅРѕРјРµСЂ С‚РµР»РµС„РѕРЅР° РёР· РјРѕРµРіРѕ РїСЂРѕС„РёР»СЏ РІ СЌС‚РѕРј РїРѕСЃС‚Рµ Рѕ РїРѕС‚РµСЂСЏРЅРЅРѕРј РїРёС‚РѕРјС†Рµ.',
      _ => 'Show my profile phone number publicly on this lost-pet post.',
    };
  }

  String get phonePublicConsentSubtitle {
    return switch (this) {
      _UzbekStrings() =>
        'Lenta yoki yoвЂqolgan jonivor sahifasini koвЂrgan odamlar shu raqamga qoвЂngвЂiroq qilishi mumkin.',
      _RussianStrings() =>
        'Р›СЋРґРё, РєРѕС‚РѕСЂС‹Рµ СѓРІРёРґСЏС‚ Р»РµРЅС‚Сѓ РёР»Рё СЃС‚СЂР°РЅРёС†Сѓ РїРѕС‚РµСЂСЏРЅРЅРѕРіРѕ РїРёС‚РѕРјС†Р°, СЃРјРѕРіСѓС‚ РїРѕР·РІРѕРЅРёС‚СЊ РЅР° СЌС‚РѕС‚ РЅРѕРјРµСЂ.',
      _ => 'People who view the feed or lost-pet page can call this number.',
    };
  }

  String get tapMapForLastSeen {
    return switch (this) {
      _UzbekStrings() => 'Jonivor oxirgi koвЂrilgan joyni xaritada bosing.',
      _RussianStrings() =>
        'РќР°Р¶РјРёС‚Рµ РЅР° РєР°СЂС‚Сѓ, РіРґРµ РїРёС‚РѕРјС†Р° РІРёРґРµР»Рё РІ РїРѕСЃР»РµРґРЅРёР№ СЂР°Р·.',
      _ => 'Tap the map to point where the pet was last seen.',
    };
  }

  String get lastSeenLocationSelected {
    return switch (this) {
      _UzbekStrings() => 'Oxirgi koвЂrilgan joy tanlandi.',
      _RussianStrings() => 'РњРµСЃС‚Рѕ РїРѕСЃР»РµРґРЅРµРіРѕ РѕР±РЅР°СЂСѓР¶РµРЅРёСЏ РІС‹Р±СЂР°РЅРѕ.',
      _ => 'Last-seen location selected.',
    };
  }

  String get contactOwner {
    return switch (this) {
      _UzbekStrings() => 'Egasi bilan bogвЂlanish',
      _RussianStrings() => 'РЎРІСЏР·Р°С‚СЊСЃСЏ СЃ РІР»Р°РґРµР»СЊС†РµРј',
      _ => 'Contact Owner',
    };
  }

  String get ownerPhone {
    return switch (this) {
      _UzbekStrings() => 'Egasining telefoni',
      _RussianStrings() => 'РўРµР»РµС„РѕРЅ РІР»Р°РґРµР»СЊС†Р°',
      _ => 'Owner phone',
    };
  }

  String get viewOnMap {
    return switch (this) {
      _UzbekStrings() => 'Xaritada koвЂrish',
      _RussianStrings() => 'РџРѕРєР°Р·Р°С‚СЊ РЅР° РєР°СЂС‚Рµ',
      _ => 'View on map',
    };
  }

  String get adoptionHelp {
    return switch (this) {
      _UzbekStrings() => 'Mushuk asrab olish boвЂyicha yordam',
      _RussianStrings() => 'РџРѕРјРѕС‰СЊ РїРѕ СѓСЃС‹РЅРѕРІР»РµРЅРёСЋ РєРѕС€РєРё',
      _ => 'Cat adoption help',
    };
  }

  String get adoptionHelpTooltip {
    return switch (this) {
      _UzbekStrings() => 'Mushukni qonuniy va xavfsiz asrab olish',
      _RussianStrings() => 'РљР°Рє Р·Р°РєРѕРЅРЅРѕ Рё Р±РµР·РѕРїР°СЃРЅРѕ РІР·СЏС‚СЊ РєРѕС€РєСѓ',
      _ => 'How to adopt a cat legally and safely',
    };
  }

  String get adoptionHelpDisclaimer {
    return switch (this) {
      _UzbekStrings() =>
        'Bu umumiy maвЂ™lumot. Shaxsiy vaziyatingiz uchun tuman/shahar davlat veterinariya xizmati yoki yurist bilan tekshiring.',
      _RussianStrings() =>
        'Р­С‚Рѕ РѕР±С‰Р°СЏ РёРЅС„РѕСЂРјР°С†РёСЏ. РџРѕ РІР°С€РµР№ СЃРёС‚СѓР°С†РёРё СѓС‚РѕС‡РЅРёС‚Рµ С‚СЂРµР±РѕРІР°РЅРёСЏ РІ СЂР°Р№РѕРЅРЅРѕР№/РіРѕСЂРѕРґСЃРєРѕР№ РіРѕСЃСѓРґР°СЂСЃС‚РІРµРЅРЅРѕР№ РІРµС‚РµСЂРёРЅР°СЂРЅРѕР№ СЃР»СѓР¶Р±Рµ РёР»Рё Сѓ СЋСЂРёСЃС‚Р°.',
      _ =>
        'This is general information. Confirm requirements for your situation with your district/city state veterinary service or a lawyer.',
    };
  }

  String get adoptionBeforeYouTakeCat {
    return switch (this) {
      _UzbekStrings() => 'Mushukni olib ketishdan oldin',
      _RussianStrings() => 'РџРµСЂРµРґ С‚РµРј РєР°Рє Р·Р°Р±СЂР°С‚СЊ РєРѕС€РєСѓ',
      _ => 'Before you take the cat',
    };
  }

  String get adoptionVetProcedure {
    return switch (this) {
      _UzbekStrings() => 'Veterinariya jarayoni',
      _RussianStrings() => 'Р’РµС‚РµСЂРёРЅР°СЂРЅР°СЏ РїСЂРѕС†РµРґСѓСЂР°',
      _ => 'Veterinary procedure',
    };
  }

  String get adoptionLegalCareRules {
    return switch (this) {
      _UzbekStrings() => 'Uyda saqlash qoidalari',
      _RussianStrings() => 'РџСЂР°РІРёР»Р° СЃРѕРґРµСЂР¶Р°РЅРёСЏ РґРѕРјР°',
      _ => 'Home-keeping rules',
    };
  }

  String get adoptionOfficialSources {
    return switch (this) {
      _UzbekStrings() => 'Rasmiy manbalar',
      _RussianStrings() => 'РћС„РёС†РёР°Р»СЊРЅС‹Рµ РёСЃС‚РѕС‡РЅРёРєРё',
      _ => 'Official sources',
    };
  }

  String get adoptionSourceKeepingRules {
    return switch (this) {
      _UzbekStrings() => 'Itlar va mushuklarni saqlash qoidalari',
      _RussianStrings() => 'РџСЂР°РІРёР»Р° СЃРѕРґРµСЂР¶Р°РЅРёСЏ СЃРѕР±Р°Рє Рё РєРѕС€РµРє',
      _ => 'Rules for keeping dogs and cats',
    };
  }

  String get adoptionSourceVetPassport {
    return switch (this) {
      _UzbekStrings() => 'Veterinariya pasporti va identifikatsiya',
      _RussianStrings() => 'Р’РµС‚РµСЂРёРЅР°СЂРЅС‹Р№ РїР°СЃРїРѕСЂС‚ Рё РёРґРµРЅС‚РёС„РёРєР°С†РёСЏ',
      _ => 'Veterinary passport and identification',
    };
  }

  String get adoptionSourceStrayAnimals {
    return switch (this) {
      _UzbekStrings() => 'Qarovsiz hayvonlarni tutish xizmatlari',
      _RussianStrings() => 'РЎР»СѓР¶Р±С‹ РѕС‚Р»РѕРІР° Р±РµР·РЅР°РґР·РѕСЂРЅС‹С… Р¶РёРІРѕС‚РЅС‹С…',
      _ => 'Stray animal catching services',
    };
  }

  String get deleteAccount {
    return switch (this) {
      _UzbekStrings() => 'Hisobni oвЂchirish',
      _RussianStrings() => 'РЈРґР°Р»РёС‚СЊ Р°РєРєР°СѓРЅС‚',
      _ => 'Delete account',
    };
  }

  String get confirmDeleteAccountTitle {
    return switch (this) {
      _UzbekStrings() => 'Hisob oвЂchirilsinmi?',
      _RussianStrings() => 'РЈРґР°Р»РёС‚СЊ Р°РєРєР°СѓРЅС‚?',
      _ => 'Delete account?',
    };
  }

  String get confirmDeleteAccountMessage {
    return switch (this) {
      _UzbekStrings() =>
        'Hisobingiz oвЂchirib qoвЂyiladi va sessiyangiz tugaydi. Mavjud kontent moderatsiya tarixi uchun saqlanishi mumkin.',
      _RussianStrings() =>
        'Р’Р°С€ Р°РєРєР°СѓРЅС‚ Р±СѓРґРµС‚ РѕС‚РєР»СЋС‡РµРЅ, Р° С‚РµРєСѓС‰Р°СЏ СЃРµСЃСЃРёСЏ Р·Р°РІРµСЂС€РёС‚СЃСЏ. РЎСѓС‰РµСЃС‚РІСѓСЋС‰РёР№ РєРѕРЅС‚РµРЅС‚ РјРѕР¶РµС‚ СЃРѕС…СЂР°РЅРёС‚СЊСЃСЏ РґР»СЏ РјРѕРґРµСЂР°С†РёРё.',
      _ =>
        'Your account will be deactivated and your current session will end. Existing content may remain for moderation history.',
    };
  }

  String get accountDeleted {
    return switch (this) {
      _UzbekStrings() => 'Hisob oвЂchirildi.',
      _RussianStrings() => 'РђРєРєР°СѓРЅС‚ СѓРґР°Р»РµРЅ.',
      _ => 'Account deleted.',
    };
  }

  String get couldNotDeleteAccount {
    return switch (this) {
      _UzbekStrings() => 'Hisobni oвЂchirib boвЂlmadi.',
      _RussianStrings() => 'РќРµ СѓРґР°Р»РѕСЃСЊ СѓРґР°Р»РёС‚СЊ Р°РєРєР°СѓРЅС‚.',
      _ => 'Could not delete account.',
    };
  }

  String get filters {
    return switch (this) {
      _UzbekStrings() => 'Filtrlar',
      _RussianStrings() => 'Р¤РёР»СЊС‚СЂС‹',
      _ => 'Filters',
    };
  }

  String get applyFilters {
    return switch (this) {
      _UzbekStrings() => 'Filtrlarni qoвЂllash',
      _RussianStrings() => 'РџСЂРёРјРµРЅРёС‚СЊ С„РёР»СЊС‚СЂС‹',
      _ => 'Apply filters',
    };
  }

  String showingMapItems({
    required int catCount,
    required int placeCount,
    required double latitude,
    required double longitude,
  }) {
    return switch (this) {
      _UzbekStrings() =>
        '$catCount ta mushuk va $placeCount ta joy koвЂrsatilmoqda: '
            '${latitude.toStringAsFixed(3)}, ${longitude.toStringAsFixed(3)}',
      _RussianStrings() =>
        'РџРѕРєР°Р·Р°РЅРѕ РєРѕС€РµРє: $catCount, РјРµСЃС‚: $placeCount СЂСЏРґРѕРј СЃ '
            '${latitude.toStringAsFixed(3)}, ${longitude.toStringAsFixed(3)}',
      _ => 'Showing $catCount cats and $placeCount places near '
          '${latitude.toStringAsFixed(3)}, ${longitude.toStringAsFixed(3)}',
    };
  }

  String viewComments(int count) {
    return '$viewCommentsPrefix$count$viewCommentsSuffix';
  }

  static AppStrings forLanguage(AppLanguage language) {
    return switch (language) {
      AppLanguage.uzbek => const _UzbekStrings(),
      AppLanguage.russian => const _RussianStrings(),
      AppLanguage.english => const _EnglishStrings(),
    };
  }
}

class _EnglishStrings extends AppStrings {
  const _EnglishStrings()
      : super(
          welcomeBack: 'Welcome back',
          signInToMushukistan: 'Sign in to Mushukistan',
          email: 'Email',
          emailHint: 'user@example.com',
          password: 'Password',
          login: 'Login',
          continueWithGoogle: 'Continue with Google',
          createAnAccount: 'Create an account',
          createAccount: 'Create account',
          joinMushukistan: 'Join Mushukistan',
          nameOptional: 'Name',
          register: 'Register',
          alreadyHaveAccount: 'Already have an account?',
          language: 'Language',
          emailRequired: 'Email is required.',
          invalidEmail: 'Enter a valid email address.',
          passwordRequired: 'Password is required.',
          passwordMin8: 'Password must be at least 8 characters.',
          nameTooLong: 'Name must be 100 characters or fewer.',
          verifyEmail: 'Verify email',
          confirmYourEmail: 'Confirm your email',
          verifyEmailWithoutAddress:
              'We need to confirm your email address before you can sign in.',
          verifyEmailWithAddress:
              'We need to confirm {email} before you can sign in.',
          devVerificationHelp:
              'Open the verification link from your email to finish confirming your account.',
          verifyNow: 'Verify now',
          resendVerification: 'Resend verification',
          backToLogin: 'Back to login',
          sessionCheckFailed: 'Session check failed.',
          retry: 'Retry',
          continueToLogin: 'Continue to login',
          restoringSession: 'Restoring session...',
          feed: 'Feed',
          map: 'Map',
          add: 'Add',
          leaders: 'Leaders',
          profile: 'Profile',
          addObservation: 'Add observation',
          chooseFromGallery: 'Choose from gallery',
          gallerySubtitle: 'Publishes to the feed without a map location.',
          takePhoto: 'Take photo',
          cameraSubtitle: 'Captures current location for the map.',
          refresh: 'Refresh',
          centerOnUser: 'Center on user',
          cats: 'Cats',
          vets: 'Vets',
          shops: 'Shops',
          shelters: 'Shelters',
          couldNotLoadPlaceMarkers: 'Could not load place markers.',
          couldNotLoadCatMarkers: 'Could not load cat markers.',
          couldNotResolveLocation: 'Could not resolve location.',
          sourceOpenStreetMap: 'Source: OpenStreetMap',
          sourceMushukistan: 'Source: Mushukistan verified data',
          recent: 'Recent',
          popular: 'Popular',
          nearby: 'Nearby',
          needsHelp: 'Needs help',
          injured: 'Injured',
          lostPets: 'Lost pets',
          today: 'Today',
          month: 'Month',
          allTime: 'All time',
          noObservationsYet: 'No observations yet.',
          anonymous: 'Anonymous',
          unnamedCat: 'Unnamed cat',
          openPost: 'Open post',
          like: 'Like',
          unlike: 'Unlike',
          comments: 'Comments',
          myObservations: 'My observations',
          myComments: 'My comments',
          userObservations: 'Observations',
          userComments: 'Comments',
          noCommentsYet: 'No comments yet.',
          noActivityVisible: 'This user has hidden their activity.',
          noDescription: 'No description',
          privacy: 'Privacy',
          allowPublicActivityView: 'Allow others to view my activity',
          allowPublicActivityViewSubtitle:
              'People can open your observations and comments from your profile.',
          viewCommentsPrefix: 'View ',
          viewCommentsSuffix: ' comments',
          likes: 'likes',
          leaderboard: 'Leaderboard',
          mostActive: 'Most active',
          mostPopular: 'Most popular',
          topHelpers: 'Top helpers',
          day: 'Day',
          week: 'Week',
          noLeaderboardData: 'No leaderboard data yet.',
          unnamedUser: 'Unnamed user',
          observations: 'observations',
          score: 'score',
          settings: 'Settings',
          editProfile: 'Edit profile',
          logout: 'Logout',
          confirmLogoutTitle: 'Log out?',
          confirmLogoutMessage:
              'You will need to sign in again to continue using your account.',
          cancel: 'Cancel',
          registered: 'Registered',
          likesReceived: 'Likes received',
          theme: 'Theme',
          themeAuto: 'Auto',
          themeDark: 'Dark',
          themeLight: 'Light',
          saveChanges: 'Save changes',
          changesSaved: 'Changes saved.',
          couldNotSaveChanges: 'Could not save changes.',
        );
}

class _UzbekStrings extends AppStrings {
  const _UzbekStrings()
      : super(
          welcomeBack: 'Xush kelibsiz',
          signInToMushukistan: 'Mushukistanga kiring',
          email: 'Email',
          emailHint: 'user@example.com',
          password: 'Parol',
          login: 'Kirish',
          continueWithGoogle: 'Google bilan davom etish',
          createAnAccount: 'Hisob yaratish',
          createAccount: 'Hisob yaratish',
          joinMushukistan: 'Mushukistanga qoвЂshiling',
          nameOptional: 'Ism',
          register: 'RoвЂyxatdan oвЂtish',
          alreadyHaveAccount: 'Hisobingiz bormi?',
          language: 'Til',
          emailRequired: 'Email kiritilishi kerak.',
          invalidEmail: 'ToвЂgвЂri email manzil kiriting.',
          passwordRequired: 'Parol kiritilishi kerak.',
          passwordMin8: 'Parol kamida 8 ta belgidan iborat boвЂlishi kerak.',
          nameTooLong: 'Ism 100 ta belgidan oshmasligi kerak.',
          verifyEmail: 'Emailni tasdiqlash',
          confirmYourEmail: 'Emailingizni tasdiqlang',
          verifyEmailWithoutAddress:
              'Kirishdan oldin email manzilingizni tasdiqlashimiz kerak.',
          verifyEmailWithAddress:
              'Kirishdan oldin {email} manzilini tasdiqlashimiz kerak.',
          devVerificationHelp:
              'Bu development versiyada tasdiqlash havolasi backend orqali chiqariladi. Token mavjud boвЂlsa, quyidagi tezkor tasdiqlashdan foydalaning.',
          verifyNow: 'Hozir tasdiqlash',
          resendVerification: 'Tasdiqlashni qayta yuborish',
          backToLogin: 'Kirishga qaytish',
          sessionCheckFailed: 'Sessiyani tekshirib boвЂlmadi.',
          retry: 'Qayta urinish',
          continueToLogin: 'Kirishga oвЂtish',
          restoringSession: 'Sessiya tiklanmoqda...',
          feed: 'Lenta',
          map: 'Xarita',
          add: 'QoвЂshish',
          leaders: 'Yetakchilar',
          profile: 'Profil',
          addObservation: 'Kuzatuv qoвЂshish',
          chooseFromGallery: 'Galereyadan tanlash',
          gallerySubtitle: 'Xaritadagi joylashuvsiz lentaga joylanadi.',
          takePhoto: 'Rasmga olish',
          cameraSubtitle: 'Xarita uchun joriy joylashuvni oladi.',
          refresh: 'Yangilash',
          centerOnUser: 'Joylashuvimga olib borish',
          cats: 'Mushuklar',
          vets: 'Veterinarlar',
          shops: 'DoвЂkonlar',
          shelters: 'Shelterlar',
          couldNotLoadPlaceMarkers: 'Joy markerlarini yuklab boвЂlmadi.',
          couldNotLoadCatMarkers: 'Mushuk markerlarini yuklab boвЂlmadi.',
          couldNotResolveLocation: 'Joylashuvni aniqlab boвЂlmadi.',
          sourceOpenStreetMap: 'Manba: OpenStreetMap',
          sourceMushukistan: 'Manba: Mushukistan tasdiqlangan maвЂ™lumotlari',
          recent: 'Yangi',
          popular: 'Mashhur',
          nearby: 'Yaqin',
          needsHelp: 'Yordam kerak',
          injured: 'Jarohatlangan',
          lostPets: 'YoвЂqolgan uy hayvonlari',
          today: 'Bugun',
          month: 'Oy',
          allTime: 'Hammasi',
          noObservationsYet: 'Hali kuzatuvlar yoвЂq.',
          anonymous: 'Anonim',
          unnamedCat: 'Nomsiz mushuk',
          openPost: 'Postni ochish',
          like: 'Layk',
          unlike: 'Laykni olish',
          comments: 'Izohlar',
          myObservations: 'Kuzatuvlarim',
          myComments: 'Izohlarim',
          userObservations: 'Kuzatuvlar',
          userComments: 'Izohlar',
          noCommentsYet: 'Hali izohlar yoвЂq.',
          noActivityVisible: 'Bu foydalanuvchi faolligini koвЂrsatishni yopgan.',
          noDescription: 'Tavsif yoвЂq',
          privacy: 'Maxfiylik',
          allowPublicActivityView:
              'Boshqalar faolligimni koвЂrishiga ruxsat berish',
          allowPublicActivityViewSubtitle:
              'Odamlar profilingizdan kuzatuvlaringiz va izohlaringizni ochishi mumkin.',
          viewCommentsPrefix: '',
          viewCommentsSuffix: ' ta izohni koвЂrish',
          likes: 'layk',
          leaderboard: 'Yetakchilar',
          mostActive: 'Eng faol',
          mostPopular: 'Eng mashhur',
          topHelpers: 'Eng yaxshi yordamchilar',
          day: 'Kun',
          week: 'Hafta',
          noLeaderboardData: 'Hali yetakchilar maвЂ™lumoti yoвЂq.',
          unnamedUser: 'Nomsiz foydalanuvchi',
          observations: 'kuzatuvlar',
          score: 'ball',
          settings: 'Sozlamalar',
          editProfile: 'Profilni tahrirlash',
          logout: 'Chiqish',
          confirmLogoutTitle: 'Chiqasizmi?',
          confirmLogoutMessage:
              'Hisobingizdan foydalanishda davom etish uchun qayta kirishingiz kerak boвЂladi.',
          cancel: 'Bekor qilish',
          registered: 'RoвЂyxatdan oвЂtgan',
          likesReceived: 'Olingan layklar',
          theme: 'Mavzu',
          themeAuto: 'Avto',
          themeDark: 'QorongвЂi',
          themeLight: 'YorugвЂ',
          saveChanges: 'OвЂzgarishlarni saqlash',
          changesSaved: 'OвЂzgarishlar saqlandi.',
          couldNotSaveChanges: 'OвЂzgarishlarni saqlab boвЂlmadi.',
        );
}

class _RussianStrings extends AppStrings {
  const _RussianStrings()
      : super(
          welcomeBack: 'РЎ РІРѕР·РІСЂР°С‰РµРЅРёРµРј',
          signInToMushukistan: 'Р’РѕР№С‚Рё РІ Mushukistan',
          email: 'Email',
          emailHint: 'user@example.com',
          password: 'РџР°СЂРѕР»СЊ',
          login: 'Р’РѕР№С‚Рё',
          continueWithGoogle: 'РџСЂРѕРґРѕР»Р¶РёС‚СЊ СЃ Google',
          createAnAccount: 'РЎРѕР·РґР°С‚СЊ Р°РєРєР°СѓРЅС‚',
          createAccount: 'РЎРѕР·РґР°С‚СЊ Р°РєРєР°СѓРЅС‚',
          joinMushukistan: 'РџСЂРёСЃРѕРµРґРёРЅРёС‚СЊСЃСЏ Рє Mushukistan',
          nameOptional: 'РРјСЏ',
          register: 'Р—Р°СЂРµРіРёСЃС‚СЂРёСЂРѕРІР°С‚СЊСЃСЏ',
          alreadyHaveAccount: 'РЈР¶Рµ РµСЃС‚СЊ Р°РєРєР°СѓРЅС‚?',
          language: 'РЇР·С‹Рє',
          emailRequired: 'РЈРєР°Р¶РёС‚Рµ email.',
          invalidEmail: 'Р’РІРµРґРёС‚Рµ РєРѕСЂСЂРµРєС‚РЅС‹Р№ email.',
          passwordRequired: 'РЈРєР°Р¶РёС‚Рµ РїР°СЂРѕР»СЊ.',
          passwordMin8: 'РџР°СЂРѕР»СЊ РґРѕР»Р¶РµРЅ Р±С‹С‚СЊ РЅРµ РєРѕСЂРѕС‡Рµ 8 СЃРёРјРІРѕР»РѕРІ.',
          nameTooLong: 'РРјСЏ РґРѕР»Р¶РЅРѕ Р±С‹С‚СЊ РЅРµ РґР»РёРЅРЅРµРµ 100 СЃРёРјРІРѕР»РѕРІ.',
          verifyEmail: 'РџРѕРґС‚РІРµСЂРґРёС‚Рµ email',
          confirmYourEmail: 'РџРѕРґС‚РІРµСЂРґРёС‚Рµ РІР°С€ email',
          verifyEmailWithoutAddress:
              'РџРµСЂРµРґ РІС…РѕРґРѕРј РЅСѓР¶РЅРѕ РїРѕРґС‚РІРµСЂРґРёС‚СЊ РІР°С€ email.',
          verifyEmailWithAddress: 'РџРµСЂРµРґ РІС…РѕРґРѕРј РЅСѓР¶РЅРѕ РїРѕРґС‚РІРµСЂРґРёС‚СЊ {email}.',
          devVerificationHelp:
              'Р’ СЌС‚РѕР№ development-СЃР±РѕСЂРєРµ СЃСЃС‹Р»РєР° РїРѕРґС‚РІРµСЂР¶РґРµРЅРёСЏ РІС‹РІРѕРґРёС‚СЃСЏ backend-РѕРј. Р•СЃР»Рё РґРѕСЃС‚СѓРїРµРЅ token, РёСЃРїРѕР»СЊР·СѓР№С‚Рµ Р±С‹СЃС‚СЂРѕРµ РїРѕРґС‚РІРµСЂР¶РґРµРЅРёРµ РЅРёР¶Рµ.',
          verifyNow: 'РџРѕРґС‚РІРµСЂРґРёС‚СЊ СЃРµР№С‡Р°СЃ',
          resendVerification: 'РћС‚РїСЂР°РІРёС‚СЊ РїРѕРґС‚РІРµСЂР¶РґРµРЅРёРµ СЃРЅРѕРІР°',
          backToLogin: 'РќР°Р·Р°Рґ РєРѕ РІС…РѕРґСѓ',
          sessionCheckFailed: 'РќРµ СѓРґР°Р»РѕСЃСЊ РїСЂРѕРІРµСЂРёС‚СЊ СЃРµСЃСЃРёСЋ.',
          retry: 'РџРѕРІС‚РѕСЂРёС‚СЊ',
          continueToLogin: 'РџРµСЂРµР№С‚Рё РєРѕ РІС…РѕРґСѓ',
          restoringSession: 'Р’РѕСЃСЃС‚Р°РЅРѕРІР»РµРЅРёРµ СЃРµСЃСЃРёРё...',
          feed: 'Р›РµРЅС‚Р°',
          map: 'РљР°СЂС‚Р°',
          add: 'Р”РѕР±Р°РІРёС‚СЊ',
          leaders: 'Р›РёРґРµСЂС‹',
          profile: 'РџСЂРѕС„РёР»СЊ',
          addObservation: 'Р”РѕР±Р°РІРёС‚СЊ РЅР°Р±Р»СЋРґРµРЅРёРµ',
          chooseFromGallery: 'Р’С‹Р±СЂР°С‚СЊ РёР· РіР°Р»РµСЂРµРё',
          gallerySubtitle: 'РџСѓР±Р»РёРєСѓРµС‚СЃСЏ РІ Р»РµРЅС‚Сѓ Р±РµР· С‚РѕС‡РєРё РЅР° РєР°СЂС‚Рµ.',
          takePhoto: 'РЎРґРµР»Р°С‚СЊ С„РѕС‚Рѕ',
          cameraSubtitle: 'РЎРѕС…СЂР°РЅСЏРµС‚ С‚РµРєСѓС‰СѓСЋ РіРµРѕРїРѕР·РёС†РёСЋ РґР»СЏ РєР°СЂС‚С‹.',
          refresh: 'РћР±РЅРѕРІРёС‚СЊ',
          centerOnUser: 'Рљ РјРѕРµРјСѓ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёСЋ',
          cats: 'РљРѕС€РєРё',
          vets: 'Р’РµС‚РєР»РёРЅРёРєРё',
          shops: 'РњР°РіР°Р·РёРЅС‹',
          shelters: 'РџСЂРёСЋС‚С‹',
          couldNotLoadPlaceMarkers: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РјРµСЃС‚Р°.',
          couldNotLoadCatMarkers: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РєРѕС€РµРє.',
          couldNotResolveLocation: 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕРїСЂРµРґРµР»РёС‚СЊ РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ.',
          sourceOpenStreetMap: 'РСЃС‚РѕС‡РЅРёРє: OpenStreetMap',
          sourceMushukistan: 'РСЃС‚РѕС‡РЅРёРє: РїСЂРѕРІРµСЂРµРЅРЅС‹Рµ РґР°РЅРЅС‹Рµ Mushukistan',
          recent: 'РќРѕРІС‹Рµ',
          popular: 'РџРѕРїСѓР»СЏСЂРЅС‹Рµ',
          nearby: 'Р СЏРґРѕРј',
          needsHelp: 'РќСѓР¶РЅР° РїРѕРјРѕС‰СЊ',
          injured: 'Р Р°РЅРµРЅС‹Рµ',
          lostPets: 'РџРѕС‚РµСЂСЏРЅРЅС‹Рµ РїРёС‚РѕРјС†С‹',
          today: 'РЎРµРіРѕРґРЅСЏ',
          month: 'РњРµСЃСЏС†',
          allTime: 'Р’СЃРµ РІСЂРµРјСЏ',
          noObservationsYet: 'РќР°Р±Р»СЋРґРµРЅРёР№ РїРѕРєР° РЅРµС‚.',
          anonymous: 'РђРЅРѕРЅРёРј',
          unnamedCat: 'РљРѕС€РєР° Р±РµР· РёРјРµРЅРё',
          openPost: 'РћС‚РєСЂС‹С‚СЊ РїРѕСЃС‚',
          like: 'Р›Р°Р№Рє',
          unlike: 'РЈР±СЂР°С‚СЊ Р»Р°Р№Рє',
          comments: 'РљРѕРјРјРµРЅС‚Р°СЂРёРё',
          myObservations: 'РњРѕРё РЅР°Р±Р»СЋРґРµРЅРёСЏ',
          myComments: 'РњРѕРё РєРѕРјРјРµРЅС‚Р°СЂРёРё',
          userObservations: 'РќР°Р±Р»СЋРґРµРЅРёСЏ',
          userComments: 'РљРѕРјРјРµРЅС‚Р°СЂРёРё',
          noCommentsYet: 'РљРѕРјРјРµРЅС‚Р°СЂРёРµРІ РїРѕРєР° РЅРµС‚.',
          noActivityVisible: 'Р­С‚РѕС‚ РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ СЃРєСЂС‹Р» СЃРІРѕСЋ Р°РєС‚РёРІРЅРѕСЃС‚СЊ.',
          noDescription: 'РќРµС‚ РѕРїРёСЃР°РЅРёСЏ',
          privacy: 'РџСЂРёРІР°С‚РЅРѕСЃС‚СЊ',
          allowPublicActivityView: 'Р Р°Р·СЂРµС€РёС‚СЊ РґСЂСѓРіРёРј РІРёРґРµС‚СЊ РјРѕСЋ Р°РєС‚РёРІРЅРѕСЃС‚СЊ',
          allowPublicActivityViewSubtitle:
              'Р›СЋРґРё СЃРјРѕРіСѓС‚ РѕС‚РєСЂС‹РІР°С‚СЊ РІР°С€Рё РЅР°Р±Р»СЋРґРµРЅРёСЏ Рё РєРѕРјРјРµРЅС‚Р°СЂРёРё РёР· РїСЂРѕС„РёР»СЏ.',
          viewCommentsPrefix: 'РџРѕРєР°Р·Р°С‚СЊ РєРѕРјРјРµРЅС‚Р°СЂРёРё: ',
          viewCommentsSuffix: '',
          likes: 'Р»Р°Р№РєРѕРІ',
          leaderboard: 'Р›РёРґРµСЂС‹',
          mostActive: 'РЎР°РјС‹Рµ Р°РєС‚РёРІРЅС‹Рµ',
          mostPopular: 'РЎР°РјС‹Рµ РїРѕРїСѓР»СЏСЂРЅС‹Рµ',
          topHelpers: 'Р›СѓС‡С€РёРµ РїРѕРјРѕС‰РЅРёРєРё',
          day: 'Р”РµРЅСЊ',
          week: 'РќРµРґРµР»СЏ',
          noLeaderboardData: 'Р”Р°РЅРЅС‹С… Р»РёРґРµСЂР±РѕСЂРґР° РїРѕРєР° РЅРµС‚.',
          unnamedUser: 'РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ Р±РµР· РёРјРµРЅРё',
          observations: 'РЅР°Р±Р»СЋРґРµРЅРёР№',
          score: 'Р±Р°Р»Р»С‹',
          settings: 'РќР°СЃС‚СЂРѕР№РєРё',
          editProfile: 'Р РµРґР°РєС‚РёСЂРѕРІР°С‚СЊ РїСЂРѕС„РёР»СЊ',
          logout: 'Р’С‹Р№С‚Рё',
          confirmLogoutTitle: 'Р’С‹Р№С‚Рё?',
          confirmLogoutMessage:
              'Р§С‚РѕР±С‹ РїСЂРѕРґРѕР»Р¶РёС‚СЊ РїРѕР»СЊР·РѕРІР°С‚СЊСЃСЏ Р°РєРєР°СѓРЅС‚РѕРј, РЅСѓР¶РЅРѕ Р±СѓРґРµС‚ РІРѕР№С‚Рё СЃРЅРѕРІР°.',
          cancel: 'РћС‚РјРµРЅР°',
          registered: 'Р”Р°С‚Р° СЂРµРіРёСЃС‚СЂР°С†РёРё',
          likesReceived: 'РџРѕР»СѓС‡РµРЅРѕ Р»Р°Р№РєРѕРІ',
          theme: 'РўРµРјР°',
          themeAuto: 'РђРІС‚Рѕ',
          themeDark: 'РўРµРјРЅР°СЏ',
          themeLight: 'РЎРІРµС‚Р»Р°СЏ',
          saveChanges: 'РЎРѕС…СЂР°РЅРёС‚СЊ РёР·РјРµРЅРµРЅРёСЏ',
          changesSaved: 'РР·РјРµРЅРµРЅРёСЏ СЃРѕС…СЂР°РЅРµРЅС‹.',
          couldNotSaveChanges: 'РќРµ СѓРґР°Р»РѕСЃСЊ СЃРѕС…СЂР°РЅРёС‚СЊ РёР·РјРµРЅРµРЅРёСЏ.',
        );
}
